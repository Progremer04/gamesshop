<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diet</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">
    <link rel="stylesheet" href="access/css/style.css">
    <!-- font google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kode+Mono:wght@400..700&display=swap" rel="stylesheet">
</head>
<style>
    /* Style for readonly textarea */
    textarea[readonly] {
        width: 100%;
        padding: 10px;
        margin-top: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        background-color: #f9f9f9;
        resize: vertical;
        /* Allow vertical resizing */
        font-family: 'Kode Mono', monospace;
        font-size: 14px;
        line-height: 1.5;
    }

    textarea[readonly]:focus {
        outline: none;
    }

    header nav ul li a:hover {
        background-color: #494949;
        color: #fff;
        padding: 6px;
        border-bottom-color: dodgerblue;
        border-right-color: dodgerblue;
        font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        text-shadow: 10px 5px 4px black;
        transition: all 0.3s;
    }
        /* CSS for video cards */
.video-card {
    background-color: #f0f0f0;
    border-radius: 10px;
    padding: 10px;
    margin-bottom: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.3s ease;
}

.video-card:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

.video-container {
    position: relative;
    overflow: hidden;
    border-radius: 8px;
}

.video-container video {
    width: 100%;
    height: auto;
}

.download-link {
    text-align: center;
    margin-top: 10px;
}

.download-link a {
    color: dodgerblue;
    text-decoration: none;
    font-weight: bold;
}

.download-link a:hover {
    text-decoration: underline;
}

</style>

<body>
    <header>
        <a href="/index.php">
            <div class="logo"><img src="/access/image/image.png" alt="it's logo"></div>
        </a>
        <input type="checkbox" id="nav_check" hidden>
        <nav>
            <ul>
                <li><a href="/access/php/contact.php" target="_blank" rel="noopener noreferrer" class="active">Contact
                        us</a></li>
                <li><a href="/access/php/article.php" target="_blank" rel="noopener noreferrer">Les Article</a></li>
                <li><a href="/access/php/equivalence.php" target="_blank" rel="noopener noreferrer">Les éqivalance</a></li>
                <li><a href="/access/php/calcule.php" target="_blank" rel="noopener noreferrer">Les Calcules</a></li>
            </ul>
        </nav>
        <label for="nav_check" class="hamburger">
            <div></div>
            <div></div>
            <div></div>
        </label>
    </header>
    <main>
        <div class="contain_page">
            <div class="wrapper">
                <h1 class="changing-text" id="changingText">Welcome to Your <br> Bread Diet Journey</h1>
            </div>
        </div>
        <div class="contain">
            <h3 class="neon-text">Phsilogie</h3>
            <div class="grid_contain_video">
                <?php
                // Database connection
                $servername = "localhost";
                $username = "id21942922_root";
                $password = "Amine@2004";
                $database = "id21942922_dietyour"; // Replace with your actual database name

                // Create connection
                $conn = new mysqli($servername, $username, $password, $database);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Retrieve videos from database
                $sql = "SELECT * FROM physiologies";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="video-card">';
                        echo "<p>Title: " . $row["title"] . "</p>";
                        echo "<div class='video-container'>";
                        echo "<video width='320' height='240' controls>";
                        echo "<source src='" . $row["video_path"] . "' type='video/mp4'>";
                        echo "Your browser does not support the video tag.";
                        echo "</video>";
                        echo "</div>";
                        echo "<div class='download-link'><a href='" . $row["video_path"] . "' download>Download Video</a></div>";
                        echo '</div>';
                    }
                } else {
                    echo "No videos found.";
                }

                $conn->close();
                ?>
            </div>
            <h3 class="neon-text">Phsiopath</h3>
            <div class="grid_contain_article">
                <?php
                // Database connection
                $servername = "localhost";
                $username = "id21942922_root";
                $password = "Amine@2004";
                $database = "id21942922_dietyour"; // Replace with your actual database name

                // Create connection
                $conn = new mysqli($servername, $username, $password, $database);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // SQL query to fetch articles along with their associated files and links
                $sql = "SELECT a.id, a.title, a.content, a.type, a.place_main, 
        GROUP_CONCAT(DISTINCT af.file_path SEPARATOR ',') AS file_paths, 
        GROUP_CONCAT(DISTINCT al.link_url SEPARATOR ',') AS link_urls
        FROM articles a
        LEFT JOIN article_files af ON a.id = af.article_id
        LEFT JOIN article_links al ON a.id = al.article_id
        WHERE a.place_main = 'Phsiopath'
        GROUP BY a.id";

                // Execute SQL query
                $result = $conn->query($sql);

                // Check if there are articles
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="grid_iteam article">';
                        echo '<h2>' . $row['title'] . '</h2>';
                        $word_count = str_word_count($row['content']);
                        $rows = ceil($word_count / 10) + 2; // Assuming 10 words per row
                        $columns = 90; // You can adjust this value as needed
                        echo '<textarea readonly rows="' . $rows . '" cols="' . $columns . '">' . $row['content'] . '</textarea>';
                        // Check if article type is 2 (words and photos)
                        if ($row['type'] == 2) {
                            $photos = explode(',', $row['file_paths']);
                            foreach ($photos as $photo) {
                                echo '<img src="' . $photo . '" alt="Article Image">';
                            }
                        }
                        // Check if article type is 3 (words and links)
                        elseif ($row['type'] == 3) {
                            $sql_links = "SELECT * FROM article_links WHERE article_id=" . $row["id"];
                            $result_links = $conn->query($sql_links);
                            $i = 1;
                            if ($result_links->num_rows > 0) {
                                echo "<p><strong>Links :</strong></p>";
                                echo "<ul class='list-disc pl-5'>";
                                while ($link_row = $result_links->fetch_assoc()) {
                                    $link = $link_row["link_url"];
                                    echo "<li>";
                                    echo "Link {$i}: <a href='$link' class='text-blue-500' target='_blank'>link {$i}</a>";
                                    echo "</li>";
                                    $i++;
                                }
                                echo "</ul>";
                            }
                        }
                        echo '</div>'; // Close article card
                    }
                } else {
                    echo "No articles found.";
                }

                $conn->close();
                ?>
            </div>
        </div>
    </main>
    <script src="/access/js/script.js"></script>
</body>

</html>
