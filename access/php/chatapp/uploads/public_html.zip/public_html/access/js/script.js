// Wrapper text
const phrases = ["Welcome to Your <br> Bread Diet Journey", "Discover Healthy <br> Eating Habits", "Achieve Your <br> Wellness Goals", "Join To <br> Our Supportive Community"];
const changingText = document.getElementById("changingText");

let index = 0;

function changeText() {
    changingText.innerHTML = phrases[index]; // Use innerHTML instead of textContent
    index = (index + 1) % phrases.length;
}

setInterval(changeText, 3000); // Change text every 3 seconds (adjust timing as needed)
