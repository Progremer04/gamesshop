<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Article</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 36px;
            color: #fff;
            margin-top: 0;
            text-align: center;
        }

        .article {
            padding: 20px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .article:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .article h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 10px;
        }

        .article p {
            font-size: 16px;
            line-height: 1.6;
            color: #666;
        }

        .article img {
            max-width: 100%;
            height: auto;
            margin-bottom: 10px;
            display: block;
            border-radius: 8px;
        }

        .article a {
            color: #007bff;
            text-decoration: none;
        }

        .article a:hover {
            text-decoration: underline;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            width: 100%;
            position: absolute;
            bottom: 0;
            left: 0;
        }

        .pagination {
            margin-top: 20px;
            text-align: center;
        }

        .pagination a {
            color: #007bff;
            text-decoration: none;
            margin: 0 5px;
            padding: 5px 10px;
            border: 1px solid #007bff;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .pagination a:hover {
            background-color: #007bff;
            color: #fff;
        }

        .textarea-container {
            position: relative;
            margin-bottom: 20px;
        }

        .textarea-container textarea {
            width: 100%;
            min-height: 200px;
            resize: none;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
            color: #666;
            background-color: #f9f9f9;
            overflow-y: auto;
        }

        .textarea-container textarea[readonly] {
            background-color: #fff;
            cursor: not-allowed;
        }
        .container header a{
            text-decoration:none;
            font-size: x-large;
            color: #f0f0f0;
            font-weight: bolder;
        }
    </style>
</head>

<body>

    <div class="container">
        <header>
            <h1>Article</h1>
            <a href="/index.php">Retur Home</a>
        </header>
        <?php
        // Database connection
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

        // Create connection
        $conn = new mysqli($servername, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Pagination
        $results_per_page = 5;
        if (!isset($_GET['page'])) {
            $page = 1;
        } else {
            $page = $_GET['page'];
        }
        $offset = ($page - 1) * $results_per_page;

        // SQL query to fetch articles along with their associated files and links
        $sql = "SELECT a.id, a.title, a.content, a.type, a.place_main, 
                GROUP_CONCAT(DISTINCT af.file_path SEPARATOR ',') AS file_paths, 
                GROUP_CONCAT(DISTINCT al.link_url SEPARATOR ',') AS link_urls
                FROM articles a
                LEFT JOIN article_files af ON a.id = af.article_id
                LEFT JOIN article_links al ON a.id = al.article_id
                WHERE a.place_main = 'article'
                GROUP BY a.id
                LIMIT $offset, $results_per_page";

        // Execute SQL query
        $result = $conn->query($sql);

        // Check if there are articles
        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                // Start article
                echo '<div class="article">';
                echo '<h2>' . $row['title'] . '</h2>';
                echo '<div class="textarea-container">';
                echo '<textarea readonly>' . $row['content'] . '</textarea>';
                echo '</div>';
                // Display photos if available
                if (!empty($row['file_paths'])) {
                    $photos = explode(',', $row['file_paths']);
                    foreach ($photos as $photo) {
                        echo '<img src="/access/php/admin_page/' . $photo . '" alt="Article Image">';
                    }
                }
                // Display links if available
                if (!empty($row['link_urls'])) {
                    $links = explode(',', $row['link_urls']);
                    foreach ($links as $link) {
                        echo '<p><a href="' . $link . '">Read More</a></p>';
                    }
                }
                echo '</div>'; // End article
            }
            // Pagination links
            $sql = "SELECT COUNT(*) AS total FROM articles WHERE place_main = 'article'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            $total_pages = ceil($row["total"] / $results_per_page);
            echo '<div class="pagination">';
            for ($i = 1; $i <= $total_pages; $i++) {
                echo '<a href="?page=' . $i . '">' . $i . '</a>';
            }
            echo '</div>';
        } else {
            echo "No articles found.";
        }

        // Close connection
        $conn->close();
        ?>

    </div>

</body>

</html>
