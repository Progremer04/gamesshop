<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equivalence</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">
    <link rel="stylesheet" href="access/css/style.css">
    <!-- font google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kode+Mono:wght@400..700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #f2f2f2;
            padding: 10px 0;
            text-align: center;
        }

        header .logo img {
            height: 50px;
            width: auto;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        main {
            padding: 20px;
        }

        .contain_page {
            background-color: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .contain_page h1 {
            margin: 0;
            font-size: 32px;
        }

        .contain h3 {
            color: #007bff;
        }

        .grid_contain_equivalence {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            grid-gap: 20px;
            margin-top: 20px;
        }

        .grid_contain_equivalence .grid_item {
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        .grid_contain_equivalence .grid_item h2 {
            margin-top: 0;
        }

        .grid_contain_equivalence .grid_item p {
            margin-bottom: 10px;
        }

        .grid_contain_equivalence .grid_item img {
            max-width: 100%;
            height: auto;
            margin-bottom: 10px;
        }
        .contain header a{
            text-decoration:none;
            font-size: x-large;
            color: #000;
            font-weight: bolder;
        }
    </style>
</head>

<body>
    
    <main>
        <div class="contain">
        <header>
        <h3 class="neon-text">Equivalence</h3>
        <a href="/index.php" target="_blank" >Retur Home</a>
        </header>    
            
            <div class="grid_contain_equivalence">
                <?php
                // Fetch equivalence data
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

                // Create connection
                $conn = new mysqli($servername, $username, $password, $database);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT * FROM equivalence";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="grid_item">';
                        echo '<h2>' . $row['title'] . '</h2>';
                        echo '<p>' . $row['description'] . '</p>';

                        // Fetch and display images related to the equivalence
                        $equivalence_id = $row['id'];
                        $sql_images = "SELECT * FROM equivalence_images WHERE equivalence_id = $equivalence_id";
                        $result_images = $conn->query($sql_images);

                        if ($result_images->num_rows > 0) {
                            while ($row_image = $result_images->fetch_assoc()) {
                                // Update image path if it contains 'uploads/'
                                echo '<img src="/access/php/admin_page/' . $row_image['image_path'] . '" alt="Equivalence Image">';
                            }
                        } else {
                            echo "No images found for this equivalence.";
                        }

                        echo '</div>';
                    }
                } else {
                    echo "No equivalence found.";
                }
                $conn->close();
                ?>
            </div>
        </div>
    </main>
    <script src="/access/js/script.js"></script>
</body>

</html>
