<?php
// Database connection
$servername = "localhost";
$username = "id21942922_root";
$password = "Amine@2004";
$dbname = "id21942922_dietyour"; // Replace with your actual database name
 
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST["submit"])) {
    $title = $_POST["title"];
    $video_name = $_FILES["video"]["name"];
    $video_tmp = $_FILES["video"]["tmp_name"];
    $uploads_dir = __DIR__ . "/uploads/";
    $video_path = $uploads_dir . $video_name;

    // Move uploaded file to the designated folder
    if (!file_exists($uploads_dir)) {
        mkdir($uploads_dir, 0777, true);
    }

    if (move_uploaded_file($video_tmp, $video_path)) {
        // Insert into database with correct path
        $video_db_path = "/access/php/admin_page/uploads/" . $video_name;
        $sql = "INSERT INTO physiologies (title, video_path) VALUES ('$title', '$video_db_path')";

        if ($conn->query($sql) === TRUE) {
            // echo "Video uploaded successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Failed to move uploaded file.";
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Physiology</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #0e1621;
            color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            width: 80%;
            max-width: 600px;
            padding: 20px;
            border-radius: 10px;
            background-color: #1f2a38;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="file"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
            background-color: #36414e;
            color: #fff;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        input[type="submit"] {
            cursor: pointer;
        }
        input[type="file"] {
            cursor: pointer;
        }
        input[type="text"]:focus,
        input[type="file"]:focus,
        input[type="submit"]:focus {
            outline: none;
        }
        input[type="text"]:hover,
        input[type="file"]:hover,
        input[type="submit"]:hover {
            background-color: #5e6c7c;
        }
        progress {
            width: 100%;
            height: 20px;
            margin-bottom: 15px;
        }
        .progress-container {
            position: relative;
            width: 100%;
            height: 20px;
            background-color: #36414e;
            border-radius: 10px;
            overflow: hidden;
        }
        .progress-bar {
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 100%;
            background-color: #4caf50;
            border-radius: 10px;
            transition: width 0.5s;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Physiology</h2>
        <form action="" method="post" enctype="multipart/form-data" onsubmit="showProgressBar()">
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" required>
            <label for="video">Select Video:</label>
            <input type="file" name="video" id="video" accept="video/*" required>
            <div class="progress-container">
                <div class="progress-bar" id="progressBar"></div>
            </div>
            <input type="submit" value="Upload" name="submit">
            <div style="padding: 4px; width:auto; height:25px; background-color:#333; color:#f9f9f9;"><a href="/access/php/admin_page/admin_panal.php?id=<?php echo $_GET["adminid"];?>" target="_blank" rel="noopener noreferrer" style="color:#f9f9f9; font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bolder;">Return To Admin Page</a></div>

        </form>
    </div>

    <script>
        function showProgressBar() {
            var progressBar = document.getElementById('progressBar');
            progressBar.style.width = '100%';
            return false;
        }
    </script>
</body>
</html>
