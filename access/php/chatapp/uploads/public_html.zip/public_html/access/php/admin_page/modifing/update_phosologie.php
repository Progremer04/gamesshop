<?php
// Establish database connection
$servername = "localhost";
$username = "id21942922_root";
$password = "Amine@2004";
$database = "id21942922_dietyour"; // Replace with your actual database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : ''; // Get the admin ID from the URL parameter

// Check if the form is submitted and the necessary fields are not empty
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["id"]) && !empty($_POST["title"]) && !empty($_POST["link"])) {
    // Prepare and bind parameters for the update query
    $stmt = $conn->prepare("UPDATE physiologies SET title=?, link=? WHERE id=?");
    $stmt->bind_param("ssi", $title, $link, $id);

    // Set parameters and execute the update query
    $title = $_POST["title"];
    $link = $_POST["link"];
    $id = $_POST["id"];

    if ($stmt->execute()) {
        echo "Physiology updated successfully.";
    } else {
        echo "Error updating physiology: " . $conn->error;
    }
    
} 

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Physiology</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease forwards;
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
            animation: slideInDown 0.5s ease forwards;
        }

        form {
            text-align: left;
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea,
        select,
        input[type="file"],
        input[type="url"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="file"],
        input[type="url"] {
            margin-bottom: 10px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .fadeIn {
            animation: fadeIn 0.5s ease forwards;
        }

        #linksContainer {
            margin-bottom: 20px;
        }

        #addLink {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 8px 12px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        #addLink:hover {
            background-color: #0056b3;
        }

        .preview-container {
            margin-bottom: 20px;
        }

        .preview-container img,
        .preview-container .file-name {
            display: block;
            margin-bottom: 5px;
        }

        .preview-container .delete-button {
            color: red;
            cursor: pointer;
            display: inline-block;
            margin-left: 10px;
        }

        .preview-container .delete-button:hover {
            text-decoration: underline;
        }

        .file-preview {
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            display: inline-block;
        }

        @media screen and (max-width: 600px) {
            form {
                padding: 0 20px;
            }

            input[type="text"],
            textarea,
            select,
            input[type="file"],
            input[type="url"] {
                width: calc(100% - 20px);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        button[type="submit"],
        button[type="reset"] {
            width: 48%;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        button[type="submit"]:hover,
        button[type="reset"]:hover {
            background-color: #0056b3;
        }

        #addLink {
            width: 48%;
            padding: 20px;
            margin-top: auto;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Courier New', Courier, monospace;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        .card {
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, color 0.3s;
        }

        .card:hover {
            background-color: #333;
            color: #ffffff;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Update Physiology</h2>
        <div class="card">
            <div class="content">
                <h3>Old Information</h3>
                <?php
                // Establish database connection
                $servername = "localhost";
                $username = "id21942922_root";
                $password = "Amine@2004";
                $database = "id21942922_dietyour"; // Replace with your actual database name
        
                $conn = new mysqli($servername, $username, $password, $database);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch old information based on the ID passed via GET method
                if (isset($_GET['id'])) {
                    $physiology_id = $_GET['id'];
                    $sql = "SELECT * FROM physiologies WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $physiology_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<p><strong>Title:</strong> " . $row["title"] . "</p>";
                            echo "<p><strong>Link:</strong> " . $row["link"] . "</p>";
                        }
                    } else {
                        echo "No old information found.";
                    }
                } else {
                    echo "No ID provided.";
                }

                $conn->close();
                ?>
            </div>
        </div>
        <form method="post" action="/access/php/admin_page/modifing/update_phosologie.php" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo isset($_GET['id']) ? $_GET['id'] : ''; ?>">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required><br>

            <label for="link">Link:</label>
            <input type="url" id="link" name="link" required><br>

            <button type="submit" onclick="return confirm('Are you sure you want to update this physiology?')">Update </button>
            <button type="reset">Reset</button>
            <div style="padding: 4px; width:auto; height:25px; background-color:#333; color:#f9f9f9;"><a href="/access/php/admin_page/admin_panal.php?id="<?php echo $admin_id;?>" target="_blank" rel="noopener noreferrer" style="color:#f9f9f9; font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bolder;">Return To Admin Page</a></div>

        </form>
    </div>
</body>

</html>
