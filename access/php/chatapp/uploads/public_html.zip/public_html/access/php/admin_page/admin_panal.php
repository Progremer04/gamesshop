<?php
       $servername = "localhost";
       $username = "id21942922_root";
       $password = "Amine@2004";
       $database = "id21942922_dietyour"; // Replace with your actual database name


// Pagination configuration
$results_per_page = 10; // Show 15 elements per page
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($current_page - 1) * $results_per_page;

// Connect to the database
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve total number of elements for each section
$sql_counts = array(
    "articles" => "SELECT COUNT(*) AS total FROM articles",
    "admins" => "SELECT COUNT(*) AS total FROM admins",
    "equivalence" => "SELECT COUNT(*) AS total FROM equivalence",
    "physiologies" => "SELECT COUNT(*) AS total FROM physiologies",
    "users" => "SELECT COUNT(*) AS total FROM users"
    // Add queries for other sections here
);


$total_counts = array();

foreach ($sql_counts as $section => $sql_count) {
    $result_count = $conn->query($sql_count);
    $row_count = $result_count->fetch_assoc();
    $total_counts[$section] = $row_count['total'];
}

// Calculate total number of pages for each section
$total_pages = array();
foreach ($total_counts as $section => $total_count) {
    $total_pages[$section] = ceil($total_count / $results_per_page);
}
?>
<?php

$iddd = isset($_GET['id']) ? $_GET['id'] : null;
$admin_id = $iddd;
if (isset($_GET['id'])) {
    // Retrieve the user ID from the URL
    $admin_id = $_GET['id'];

    // Fetch user information based on the provided ID
    $sql = "SELECT * FROM admins WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $adminiddd = $result->fetch_assoc();
    } else {
        echo "No Admin  found.";
        $conn->close();
        exit;
    }
}
?>

<!--  -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel <?php echo $adminiddd['firstname']; ?> <?php echo $adminiddd['lastname']; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha384-RWRLjiv5gZzcZ2/r6OzZKmteyTvaufp+xmvHblb5UpMcr3VS5bxP0P+Oy6fjG+3l" crossorigin="anonymous">
    <link rel="shortcut icon" href="/access/image/image.png" type="image/png">
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            overflow-x: hidden;
        }

        .container {
            display: grid;
            grid-template-columns: auto 1fr;
            height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            background-color: #333;
            color: #fff;
            padding: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            z-index: 1;
            transition: width 0.5s;
            overflow-y: auto;
            height: 100vh;
            position: relative;
        }

        .sidebar h1 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #ffd700;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 5px;
        }

        .sidebar a svg {
            margin-right: 10px;
            fill: #fff;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Main Content Styles */
        .main-content {
            padding: 20px;
            overflow-y: auto;
            position: relative;
        }

        /* Article Styles */
        .article {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            animation: fadeIn 0.5s ease-in-out;
            display: none;
            position: relative;
        }

        .article.active {
            display: block;
        }

        .article.active::before {
            content: '';
            position: absolute;
            top: 0;
            left: -20px;
            width: 6px;
            height: 100%;
            background-color: #ffd700;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .article h2 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #333;
        }

        .article p {
            line-height: 1.6;
            color: #666;
        }

        /* Submenu Styles */
        .submenu {
            margin-top: 20px;
            padding-left: 20px;
            border-left: 2px solid #ffd700;
        }

        .submenu a {
            color: #ffd700;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
            transition: all 0.3s ease;
            padding: 5px;
            border-radius: 3px;
        }

        .submenu a:hover {
            background-color: #555;
        }

        /* Responsive Styles */
        @media only screen and (max-width: 768px) {
            .container {
                grid-template-columns: 1fr;
            }

            .sidebar {
                width: 100%;
                position: static;
                box-shadow: none;
            }

            .main-content {
                padding: 20px;
            }

            .article.active::before {
                display: none;
            }
        }

        /* Card Styles */
        .card {
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 10px;
            color: #333;
        }

        .card p {
            font-size: 16px;
            margin-bottom: 15px;
            color: #666;
        }

        .card .label {
            font-weight: bold;
        }

        .card .data {
            margin-left: 10px;
        }

        .card .data ul {
            padding: 0;
        }

        .card .data li {
            list-style: none;
            margin-bottom: 5px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            /* Adjust the width of each column as needed */
            gap: 20px;
            /* Adjust the gap between cards */
        }

        .grid .card {
            background-color: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .grid .card .content {
            padding: 20px;
        }

        .grid .card p {
            margin-bottom: 10px;
        }

        .grid .card textarea {
            width: 100%;
            min-height: 100px;
            resize: vertical;
            margin-bottom: 10px;
        }

        .grid .card img {
            max-width: 100%;
            height: auto;
            margin-bottom: 10px;
        }

        .grid .card ul {
            list-style-type: disc;
            padding-left: 20px;
        }

        .grid .card ul li {
            margin-bottom: 5px;
        }

        .pagination {
            margin-top: 20px;
        }

        .pagination a {
            text-decoration: none;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 5px;
            color: #333;
        }

        .pagination a.active {
            background-color: #ffd700;
            color: #fff;
            border: 1px solid #ffd700;
        }

        .video-container {
            position: relative;
            width: 100%;
            padding-bottom: 56.25%;
            /* 16:9 aspect ratio (height/width) */
            overflow: hidden;
        }

        .video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .contain_two_btn {
            display: flex;
            justify-content: space-between;
        }

        .contain_two_btn a {
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .delete-btn {
            background-color: #FF6347;
            /* Tomato */
            color: #fff;
        }

        .modify-btn {
            background-color: #4169E1;
            /* Royal Blue */
            color: #fff;
        }

        .contain_two_btn a:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .delete-btn:hover {
            background-color: #CD5C5C;
            /* Indian Red */
        }

        .modify-btn:hover {
            background-color: #6495ED;
            /* Cornflower Blue */
        }

        .contain_two_btn a:active {
            transform: translateY(0);
            box-shadow: none;
        }

        @media only screen and (max-width: 480px) {
            .contain_two_btn {
                flex-direction: column;
                align-items: stretch;
            }

            .contain_two_btn a {
                margin-bottom: 10px;
            }
        }

        .card {
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, color 0.3s;
        }

        .card:hover {
            background-color: #333;
            color: #ffffff;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <a href="#" id="homePageLink">
                <h1>Diet Your Home Page</h1>
            </a>
            <ul>
                <li>
                    <a href="#eqivalance" onclick="showArticle('eqivalance','#333');">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z" />
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14l-4-4 1.41-1.41L10 13.17l6.59-6.59L18 8l-8 8z" />
                        </svg> LES ÉQUIVALENCES
                    </a>
                </li>
                <li>
                    <a href="#physiologies" onclick="showArticle('physiologies','#333');">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z" />
                            <path d="M21 7H3V3h18v4zM3 17h18v-4H3v4zm0-8h18V7H3v2zm3 3h4v2H6v-2zm0 4h4v2H6v-2zm5 0h4v2h-4v-2zm5-4h4v2h-4v-2zm0 4h4v2h-4v-2z" />
                        </svg> LES PHYSIOLOGIES
                    </a>
                </li>
                <li>
                    <a href="#messages" onclick="showArticle('messages','#333');">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z" />
                            <path d="M21 2H3c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-1 6l-5 4.29L4 8V4h16v4zm-5 6.21L20 12V18H4v-6l4 3.79L15 12z" />
                        </svg> LES Utilisation
                    </a>
                </li>
                <li>
                    <a href="#articles" onclick="showArticle('articles','#333');">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z" />
                            <path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm-1 13.38l-3.72-2.8L12 15.2l-3.28 2.38L5 17.38V6h14v11.38z" />
                        </svg> LES ARTICLES
                    </a>
                </li>
                <li>
                    <a href="#admins" onclick="showArticle('admins','#333');">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z" />
                            <path d="M21 6V4c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v2h18zm-4 3c1.1 0 2 .9 2 2v9c0 1.1-.9 2-2 2H7c-1.1 0-2-.9-2-2v-9c0-1.1.9-2 2-2h10zm-5 9h2v-2h-2v2zm0-4h2V8h-2v6z" />
                        </svg> LES ADMINISTRATEURS
                    </a>
                </li>
                <li>
                    <a href="#" id="homePageLink1">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <!-- Doctors logo -->
                            <path fill="#fff" d="M12,15c-3.866,0-7-3.134-7-7s3.134-7,7-7s7,3.134,7,7S15.866,15,12,15z M12,3C9.239,3,7,5.239,7,8
            s2.239,5,5,5s5-2.239,5-5S14.761,3,12,3z" />
                            <!-- Calculator -->
                            <path fill="#fff" d="M21,6V4c0-1.1-0.9-2-2-2H5C3.9,2,3,2.9,3,4v2H21zM17,9c1.1,0,2,0.9,2,2v9c0,1.1-0.9,2-2,2H7c-1.1,0-2-0.9-2-2
            v-9c0-1.1,0.9-2,2-2h10zM12,18h2v-2h-2V18zM12,14h2v-2h-2V14z" />
                        </svg> LES calcules
                    </a>
                </li>


            </ul>
        </aside>

        <!-- Main Content -->
        <section class="main-content">
            <!-- Article Section -->
            <div id="articles" class="article active">
                <h2>LES Articles</h2>
                <div class="submenu">
                    <a href="/access/php/admin_page/addarticle.php?admin_id=<?php echo $adminiddd["id"];?>" target="_blank">Ajouter un Articles</a>
                </div>
                <div class="grid">
                    <?php
                    // Connect to your database here
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = "SELECT * FROM articles LIMIT $offset, $results_per_page";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<div class='card'>";
                            echo "<div class='content'>";
                            echo "<p><strong>ID:</strong> " . $row["id"] . "</p>";
                            echo "<p><strong>Title:</strong> " . $row["title"] . "</p>";
                            echo "<p><strong>Content:</strong> ";
                            echo "<textarea cols='30' rows='10' readonly>" . $row["content"] . "</textarea>";
                            // Check article type
                            if ($row["type"] == 2) {
                                echo "<p><strong>Photos :</strong></p>";
                                // Article type 2 with images
                                $sql_images = "SELECT * FROM article_files WHERE article_id=" . $row["id"];
                                $result_images = $conn->query($sql_images);
                                if ($result_images->num_rows > 0) {
                                    while ($image_row = $result_images->fetch_assoc()) {
                                        echo "<img src='" . $image_row["file_path"] . "' class='mb-2'>";
                                    }
                                }
                            } elseif ($row["type"] == 3) {
                                // Article type 3 with links
                                $sql_links = "SELECT * FROM article_links WHERE article_id=" . $row["id"];
                                $result_links = $conn->query($sql_links);
                                $i = 1;
                                if ($result_links->num_rows > 0) {
                                    echo "<p><strong>Links :</strong></p>";
                                    echo "<ul class='list-disc pl-5'>";
                                    while ($link_row = $result_links->fetch_assoc()) {
                                        $link = $link_row["link_url"];
                                        echo "<li>";
                                        echo "Link {$i}: <a href='$link' class='text-blue-500' target='_blank'>link {$i}</a>";
                                        echo "</li>";
                                        $i++;
                                    }
                                    echo "</ul>";
                                }
                            }

                            echo "<ul>";
                            echo "<li><strong>Type:</strong> " . $row["type"] . "</li>";
                            $string = ($row["place_main"] == "Phsiopath") ? "Article Showing In Main" : "Article showing in Article page";
                            echo "<li><strong>Main Place:</strong> " . $string . "</li>";
                            echo "<li><strong>Created At:</strong> " . $row["created_at"] . "</li>";
                            echo "<li><strong>Updated At:</strong> " . $row["updated_at"] . "</li>";
                            echo "</ul>";
                            echo "<div class='contain_two_btn'>";
                            echo "<a href='/access/php/admin_page/deleting/delete_article.php?id=" . $row["id"] . "&adminid=" . $adminiddd["id"] . "' class='delete-btn' onclick=\"return confirm('Are you sure you want to delete this Article?')\" target='_blank'>Delete it</a>";
                            echo "<a href='/access/php/admin_page/modifing/update_article.php?id=" . $row["id"] . "&adminid=" . $adminiddd["id"] . "' class='delete-btn' onclick=\"return confirm('Are you sure you want to Modified this Article?')\" target='_blank'>Modifte him</a>";
                            echo "</div>";
                            echo "</div>";
                            echo "</div>";
                        }
                    } else {
                        echo "0 results";
                    }
                    $conn->close();
                    ?>
                </div>

                <div class="pagination">
                    <?php for ($page = 1; $page <= $total_pages['articles']; $page++) : ?>
                        <a href="?id=<?php echo $adminiddd['id']; ?>&page=<?php echo $page; ?>&section=articles" class="<?php echo $page == $current_page ? 'active' : ''; ?>">
                            <?php echo $page; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
            <!-- Admins Section -->
            <div id="admins" class="article">
                <h2>LES ADMINISTRATEURS</h2>
                <div class="submenu">
                    <a href="/access/php/admin_page/add_admin.php?id=<?php echo $adminiddd["id"]; ?>" target="_blank">Ajouter un administrateur</a>
                </div>
                <!-- Admins Section -->
                <div class="grid">
                    <?php
                    // Connect to your database here
                    $servername = "localhost";
                    $username = "id21942922_root";
                    $password = "Amine@2004";
                    $database = "id21942922_dietyour"; // Replace with your actual database name
            

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = "SELECT * FROM admins";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<div class='card'>";
                            echo "<div class='content'>";
                            echo "<p><strong>ID:</strong> " . $row["id"] . "</p>";
                            echo "<p><strong>First Name:</strong> " . $row["firstname"] . "</p>";
                            echo "<p><strong>Last Name:</strong> " . $row["lastname"] . "</p>";
                            echo "<div class='contain_two_btn'>";
                            echo "<a href='/access/php/admin_page/deleting/delete_admin.php?id=" . $row["id"] . "&adminid=" . $adminiddd["id"] . "' class='delete-btn' onclick=\"return confirm('Are you sure you want to delete this Admin?')\" target='_blank'>Delete it</a>";
                            echo "<a href='/access/php/admin_page/modifing/update_admin.php?id=" . $row["id"] . "&adminid=" . $adminiddd["id"] . "' onclick=\"return confirm('Are you sure you want to update this Admin?')\" class='modify-btn' target='_blank'>Modify him</a>";
                            echo "</div>";
                            echo "</div>";
                            echo "</div>";
                        }
                    } else {
                        echo "0 results";
                    }
                    $conn->close();
                    ?>
                </div>
                <!-- PHP code for admins -->
                <!-- Pagination -->
                <div class="pagination">
                    <?php for ($page = 1; $page <= $total_pages['admins']; $page++) : ?>
                        <a href="?id=<?php echo $adminiddd['id']; ?>&page=<?php echo $page; ?>&section=admins" class="<?php echo $page == $current_page ? 'active' : ''; ?>">
                            <?php echo $page; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
            <div id="eqivalance" class="article">
                <h2>LES ÉQUIVALENCES</h2>
                <div class="submenu">
                    <a href="/access/php/admin_page/add_equivalence .php?id=<?php echo $adminiddd["id"]; ?>" target="_blank">Ajouter une équivalence</a>
                </div>
                <!-- Equivalences Section -->
                <div class="grid">
                    <?php
                    // Connect to your database here
                    $servername = "localhost";
                    $username = "id21942922_root";
                    $password = "Amine@2004";
                    $database = "id21942922_dietyour"; // Replace with your actual database name
            

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Query to select data from both tables
                    $sql = "SELECT equivalence.id, equivalence.title, GROUP_CONCAT(equivalence_images.image_path) AS image_paths
            FROM equivalence 
            LEFT JOIN equivalence_images 
            ON equivalence.id = equivalence_images.equivalence_id
            GROUP BY equivalence.id";

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                    ?>
                            <div class="card">
                                <div class="content">
                                    <p><strong>ID:</strong>
                                        <?php echo $row["id"]; ?>
                                    </p>
                                    <p><strong>Title:</strong>
                                        <?php echo $row["title"]; ?>
                                    </p>
                                    <?php
                                    // Check if there are associated images
                                    if ($row["image_paths"]) {
                                        // Split the image paths into an array
                                        $image_paths = explode(",", $row["image_paths"]);
                                    ?>
                                        <p><strong>Photos :</strong></p>
                                        <div class="image-container">
                                            <?php
                                            // Loop through each image path and display it
                                            foreach ($image_paths as $image_path) {
                                            ?>
                                                <img src="<?php echo $image_path; ?>" class="mb-2">
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                                <div class="contain_two_btn">
                                    <?php echo "<a href='/access/php/admin_page/deleting/delete_equivalence.php?id=" . $row["id"] . "&adminid=" . $adminiddd["id"] . "' class='delete-btn' onclick=\"return confirm('Are you sure you want to delete this equivalence?')\" target='_blank'>Delete it</a>"; ?>
                                    <a href="/access/php/admin_page/modifing/update_equivalence.php?id=<?php echo $row['id']; ?>&adminid=<?php echo $adminiddd['id']; ?>" class="modify-btn" target="_blank" onclick="return confirm('Are you sure you want to modify this equivalence?');">Modify</a>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                        echo "0 results";
                    }
                    $conn->close();
                    ?>
                </div>
                <div class="pagination">
                    <?php for ($page = 1; $page <= $total_pages['equivalence']; $page++) : ?>
                        <a href="?id=<?php echo $adminiddd['id']; ?>&page=<?php echo $page; ?>&section=equivalence" class="<?php echo $page == $current_page ? 'active' : ''; ?>">
                            <?php echo $page; ?>
                        </a>
                    <?php endfor; ?>
                </div>


            </div>
<!-- Physiologies Section -->
<div id="physiologies" class="article">
    <h2>LES PHYSIOLOGIES</h2>
    <div class="submenu">
        <a href="/access/php/admin_page/crate_phsilogie.php?adminid=<?php echo $adminiddd["id"]; ?>" target="_blank">Ajouter une physiologie</a>
    </div>
    <!-- Physiologies Section -->
    <div class="grid">
        <?php
        // Connect to your database here
        $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

        // Create connection
        $conn = new mysqli($servername, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to select data from physiologies table
        $sql = "SELECT * FROM physiologies";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
        ?>
                <div class="card">
                    <div class="content">
                        <p><strong>Title:</strong> <?php echo $row["title"]; ?></p>
                        <div class="video-container">
                            <!-- Assuming the video_path contains the URL of the video -->
                            <iframe width="560" height="315" src="<?php echo $row["video_path"]; ?>" frameborder="0" allowfullscreen></iframe>
                        </div>
                        <div class="contain_two_btn">
                            <a href="/access/php/admin_page/deleting/delete_phosologie.php?id=<?php echo $row["id"]; ?>&adminid=<?php echo $adminiddd["id"]; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this physiology?')" target="_blank">Delete it</a>
                        </div>
                    </div>
                </div>
        <?php
            }
        } else {
            echo "0 results";
        }
        $conn->close();
        ?>
    </div>
    <div class="pagination">
        <?php for ($page = 1; $page <= $total_pages['physiologies']; $page++) : ?>
            <a href="?id=<?php echo $admin['id']; ?>&page=<?php echo $page; ?>&section=physiologies" class="<?php echo $page == $current_page ? 'active' : ''; ?>">
                <?php echo $page; ?>
            </a>
        <?php endfor; ?>
    </div>
</div>

            <!-- Messages Section -->
            <div id="messages" class="article">
                <h2>LES Utilisateur</h2>
                <div class="submenu">
                    <a href="/access/php/creating_new_account_is_for_admin.php?adminid=<?php echo $adminiddd["id"] ?>" target="_blank" onclick="return confirm('Are you sure you want to add new users?')">Ajouter un Utilisateur</a>
                </div>
                <!-- Messages Section -->
                <div class="grid">
                    <!-- PHP code for users -->
                    <?php
                    // Connect to your database
                    $servername = "localhost";
                    $username = "id21942922_root";
                    $password = "Amine@2004";
                    $database = "id21942922_dietyour"; // Replace with your actual database name
            

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Query to select all data from the users table
                    $sql = "SELECT * FROM users";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                    ?>
                            <div class="card">
                                <div class="content">
                                    <p><strong>ID:</strong>
                                        <?php echo $row["id"]; ?>
                                    </p>
                                    <p><strong>First Name:</strong>
                                        <?php echo $row["firstname"]; ?>
                                    </p>
                                    <p><strong>Last Name:</strong>
                                        <?php echo $row["lastname"]; ?>
                                    </p>
                                    <p><strong>Age:</strong>
                                        <?php echo $row["age"]; ?>
                                    </p>
                                    <p><strong>Birthday:</strong>
                                        <?php echo $row["birthday"]; ?>
                                    </p>
                                    <p><strong>Gender:</strong>
                                        <?php echo $row["gender"]; ?>
                                    </p>
                                    <p><strong>City:</strong>
                                        <?php echo $row["city"]; ?>
                                    </p>
                                    <p><strong>Phone:</strong>
                                    <a href="tel:<?php echo $row['phone']; ?>"><?php echo $row['phone']; ?></a>
                                    </p>
                                    <p><strong>Weight:</strong>
                                        <?php echo $row["weight"] . "  kg"; ?>
                                    </p>
                                    <p><strong>Length:</strong>
                                        <?php echo $row["length"] . "  m"; ?>
                                    </p>
                                    <p><strong>Date Added:</strong>
                                        <?php echo $row["date_added"]; ?>
                                    </p>
                                    <div class="contain_two_btn">
                                        <a href="/access/php/admin_page/deleting/delete_user.php?id=<?php echo $row["id"]; ?>&adminid=<?php echo $adminiddd["id"] ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this user?')" target="_blank">Delete it</a>
                                        <a href="/access/php/admin_page/modifing/update_user_admin.php?id=<?php echo $row["id"]; ?>&adminid=<?php echo $adminiddd["id"] ?>" class="modify-btn" target="_blank" onclick="return confirm('Are you sure you want to modified this User?')" target='_blank'>Modifte him</a>
                                    </div>
                                    <div class="contain_two_btn">
                                        <?php echo '<a href="/access/php/chatapp/chat.php?sender_id=' . $adminiddd["id"] . '&receiver_id=' . $row['id'] . '&admin_id=' . $adminiddd["id"] . '" target="_black" class="modify-btn" >Chat with ' . $row['firstname'] . ' ' . $row['lastname'] . '</a>'; ?>
                                        <?php echo '<a href="/access/php/calcule.php?id=' . $row['id'] . '" target="_black" style="background-color: #333; color: #fff; text-decoration: none; padding: 5px;">Calculate nutrition of ' . $row['firstname'] . ' ' . $row['lastname'] . '</a>'; ?>
                                    </div>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                        echo "<p><strong>Il y' a pas Des Utilisateurs </strong>";
                    }
                    $conn->close();
                    ?>
                </div>
                <div class="pagination">
                    <?php for ($page = 1; $page <= $total_pages['users']; $page++) : ?>
                        <a href="?id=<?php echo $adminiddd['id']; ?>&page=<?php echo $page; ?>&section=users" class="<?php echo $page == $current_page ? 'active' : ''; ?>">
                            <?php echo $page; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
        </section>
    </div>


    <script>
        // Function to show the selected article
        function showArticle(articleId, defaultColor) {
            // Reset the color to default
            var sidebar = document.getElementById("sidebar");
            sidebar.style.backgroundColor = defaultColor;

            // Hide all articles
            const articles = document.querySelectorAll('.article');
            articles.forEach(article => {
                article.classList.remove('active');
            });

            // Show the selected article
            const selectedArticle = document.getElementById(articleId);
            selectedArticle.classList.add('active');
        }

        // Add event listeners to sidebar links
        var sidebarLinks = document.querySelectorAll('.sidebar a');
        sidebarLinks.forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault();
                var targetId = link.getAttribute('href').substring(1);
                showArticle(targetId, '#333'); // Pass the default color as an argument
            });
        });

        // Get the link element
        const homePageLink = document.getElementById('homePageLink');

        // Add a click event listener
        homePageLink.addEventListener('click', function(event) {
            // Prevent the default action (e.g., navigating to "#" which scrolls to the top)
            event.preventDefault();

            // Open the specified URL in a new tab
            window.open('/access/php/admin_page/admin_index.php?id=<?php echo $admin_id; ?>', '_blank');
        });
        // Get the link element
        const homePageLink1 = document.getElementById('homePageLink1');

        // Add a click event listener
        homePageLink1.addEventListener('click', function(event) {
            // Prevent the default action (e.g., navigating to "#" which scrolls to the top)
            event.preventDefault();

            // Open the specified URL in a new tab
            window.open('/access/php/calcule.php', '_blank');
        });
    </script>
</body>

</html>