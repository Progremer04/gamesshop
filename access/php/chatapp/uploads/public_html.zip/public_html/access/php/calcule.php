<?php
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

// Connect to the database
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = isset($_GET['id']) ? $_GET['id'] : null;
if ($id != null) {
    if (isset($_GET['id'])) {
        // Retrieve the user ID from the URL
        $user_id = $id;
        // Fetch user information based on the provided ID
        $sql = "SELECT * FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
        } else {
            echo "No user found.";
            $conn->close();
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculateur de nutrition</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }

        h1 {
            text-align: center;
            color: #007bff;
            margin-bottom: 30px;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: inline-block;
            width: 150px;
            font-weight: bold;
            color: #555;
        }

        .input-group input,
        .input-group select {
            width: calc(100% - 170px);
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ced4da;
            box-sizing: border-box;
        }

        .button {
            display: inline-block;
            padding: 12px 20px;
            background-color: #007bff;
            color: #fff;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #0056b3;
        }

        #resultats {
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #resultats h2 {
            color: #007bff;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        #resultats ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        #resultats li {
            margin-bottom: 10px;
            font-size: 16px;
            color: #555;
        }
    </style>
</head>

<body>
    <h1>Calculateur de nutrition</h1>
    <div class="input-group">
        <label for="poids">Poids (kg) : </label>
        <input type="number" id="poids" value="<?php echo isset($user['weight']) ? $user['weight'] : ''; ?>">
    </div>
    <div class="input-group">
        <label for="taille">Taille (m) : </label>
        <input type="number" id="taille" value="<?php echo isset($user['length']) ? $user['length'] : ''; ?>">
    </div>
    <div class="input-group">
        <label for="age">Âge : </label>
        <input type="number" id="age" value="<?php echo isset($user['age']) ? $user['age'] : ''; ?>">
    </div>
    <div class="input-group">
        <label for="sexe">Sexe : </label>
        <select id="sexe">
            <option value="homme" <?php echo (isset($user['gender']) && $user['gender'] == 'homme') ? 'selected' : ''; ?>>Homme</option>
            <option value="femme" <?php echo (isset($user['gender']) && $user['gender'] == 'femme') ? 'selected' : ''; ?>>Femme</option>
        </select>
    </div>
    <div class="input-group">
        <label for="activite">Niveau d'activité : </label>
        <select id="activite">
            <option value="1.3">Sédentaire (1.3)</option>
            <option value="1.5">Peu actif (1.5)</option>
            <option value="1.6">Modérément actif (1.6)</option>
            <option value="1.8">Très actif (1.8)</option>
        </select>
    </div>
    <div class="input-group">
        <label for="pourcentage-proteines">Pourcentage de protéines (%) : </label>
        <input type="number" id="pourcentage-proteines">
    </div>
    <div class="input-group">
        <label for="pourcentage-glucides">Pourcentage de glucides (%) : </label>
        <input type="number" id="pourcentage-glucides">
    </div>
    <div class="input-group">
        <label for="pourcentage-lipides">Pourcentage de lipides (%) : </label>
        <input type="number" id="pourcentage-lipides">
    </div>
    <div>
        <button class="button" onclick="calculer()">Calculer</button>
    </div>
    <div id="resultats" style="display: none;">
        <h2>Résultats</h2>
        <p id="indice-masse-corporelle"></p>
        <p id="poids-ideal"></p>
        <p id="metabolisme-base"></p>
        <p id="depense-energetique"></p>
        <p id="grammage-proteines"></p>
        <p id="grammage-glucides"></p>
        <p id="grammage-lipides"></p>
    </div>
    <script>
        function calculer() {
            var poids = parseFloat(document.getElementById('poids').value);
            var taille = parseFloat(document.getElementById('taille').value);
            var age = parseFloat(document.getElementById('age').value);
            var sexe = document.getElementById('sexe').value;
            var activite = parseFloat(document.getElementById('activite').value);
            var pourcentageProtéines = parseFloat(document.getElementById('pourcentage-proteines').value);
            var pourcentageGlucides = parseFloat(document.getElementById('pourcentage-glucides').value);
            var pourcentageLipides = parseFloat(document.getElementById('pourcentage-lipides').value);

            var imc = poids / ((taille) * (taille));
            var poidsIdeal = (sexe === "homme") ? ((taille *100) - 100 - (((taille *100) - 150) / 4)) : ((taille *100) - 100 - (((taille *100) - 150)) / 2); // Formule différente pour hommes et femmes
            var mb = (sexe === "homme") ? (66.5 + (13.8 * poidsIdeal) + (5 * (taille *100)) - (6.8 * age)) : (655.5(9.6 * poidsIdeal) + (1.9 * (taille *100)) - (4.5 * age)); // Formule différente pour hommes et femmes
            var de = mb * activite;

            var kcalProtéines = (pourcentageProtéines / 100) * de;
            var grammageProtéines = kcalProtéines / 4; // 4 kcal par gramme de protéines

            var kcalGlucides = (pourcentageGlucides / 100) * de;
            var grammageGlucides = kcalGlucides / 4; // 4 kcal par gramme de glucides

            var kcalLipides = (pourcentageLipides / 100) * de;
            var grammageLipides = kcalLipides / 9; // 9 kcal par gramme de lipides

            afficherResultats(imc, poidsIdeal, mb, de, grammageProtéines, grammageGlucides, grammageLipides);
        }

        function afficherResultats(imc, poidsIdeal, mb, de, grammageProtéines, grammageGlucides, grammageLipides) {
            var resultatsDiv = document.getElementById('resultats');
            resultatsDiv.innerHTML = "<h2>Résultats</h2>";
            resultatsDiv.innerHTML += "<p>Indice de masse corporelle (IMC) : " + imc.toFixed(2) + "</p>";
            resultatsDiv.innerHTML += "<p>Poids idéal : " + poidsIdeal.toFixed(2) + " kg</p>";
            resultatsDiv.innerHTML += "<p>Métabolisme de base : " + mb.toFixed(2) + " kcal/jour</p>";
            resultatsDiv.innerHTML += "<p>Dépense énergétique : " + de.toFixed(2) + " kcal/jour</p>";
            resultatsDiv.innerHTML += "<p>Kcal de protéines : " + (grammageProtéines * 4).toFixed(2) + " kcal</p>";
            resultatsDiv.innerHTML += "<p>Grammage de protéines : " + grammageProtéines.toFixed(2) + " g</p>";
            resultatsDiv.innerHTML += "<p>Kcal de glucides : " + (grammageGlucides * 4).toFixed(2) + " kcal</p>";
            resultatsDiv.innerHTML += "<p>Grammage de glucides : " + grammageGlucides.toFixed(2) + " g</p>";
            resultatsDiv.innerHTML += "<p>Kcal de lipides : " + (grammageLipides * 9).toFixed(2) + " kcal</p>";
            resultatsDiv.innerHTML += "<p>Grammage de lipides : " + grammageLipides.toFixed(2) + " g</p>";
            resultatsDiv.style.display = 'block';
        }
    </script>
</body>

</html>
