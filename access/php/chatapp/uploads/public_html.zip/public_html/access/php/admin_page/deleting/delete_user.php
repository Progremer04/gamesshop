<?php
// Check if the ID parameter is set and not empty
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Include database connection
    
    // Connect to your database here
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);
    $admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : ''; // Get the admin ID from the URL parameter

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare a DELETE statement
    $sql = "DELETE FROM users WHERE id = ?";

    // Prepare and bind the statement
    if($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $userid);

        // Set parameters
        $userid = $_GET['id'];

        // Attempt to execute the statement
        if($stmt->execute()) {
            // Redirect back to the admin page after successful deletion
            header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);
            exit();
        } else {
            // If execution fails, display an error message
            echo "Error deleting record: " . $stmt->error;
        }
    }

    // Close statement
    $stmt->close();

    // Close connection
    $conn->close();
} else {
    // If no ID parameter is provided, redirect to admin page
    header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);
    exit();
}
?>
