<?php
// Sample database connection
$servername = "localhost";
$username = "id21942922_root";
$password = "Amine@2004";
$database = "id21942922_dietyour"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : ''; // Get the admin ID from the URL parameter

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id'])){
    // Collect form data
    $id = isset($_GET['id']) ? $_GET['id'] : null;
    $firstname = isset($_POST['firstname']) ? $_POST['firstname'] : null;
    $lastname = isset($_POST['lastname']) ? $_POST['lastname'] : null;
    $password = isset($_POST['password']) ? $_POST['password'] : null;

    // Update admin data
    $sql = "UPDATE admins SET username=?, password=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $username, $password, $id);

    if ($stmt->execute() === TRUE) {
        echo "Admin data updated successfully";
        header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);

    } else {

        echo "Error updating admin data: " . $conn->error;
        header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);

    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/access/image/image.png" type="image/png">

    <title>Edit Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        .card {
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, color 0.3s;
        }

        .card:hover {
            background-color: #333;
            color: #ffffff;
        }

        .content {
            width: 100%;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .password-container {
            position: relative;
        }

        #togglePassword {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            padding: 5px;
            background-color: transparent;
            border: none;
            cursor: pointer;
            font-size: 1.5em;
        }

        input[type="submit"],
        button[type="reset"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover,
        button[type="reset"]:hover {
            background-color: #0056b3;
        }

        @media only screen and (max-width: 600px) {
            .card {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
<div class="container">
        <div class="card">
            <div class="content">

                <?php
                // Sample database connection
                $servername = "localhost";
                $username = "id21942922_root";
                $password = "Amine@2004";
                $database = "id21942922_dietyour"; // Replace with your actual database name
        
                $conn = new mysqli($servername, $username, $password, $database);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $admin = null; // Initialize $admin variable

                // Check if the admin ID is provided in the URL
                if (isset($_GET['id'])) {
                    // Retrieve the admin ID from the URL
                    $admin_id = $_GET['id'];

                    // Fetch admin information based on the provided ID
                    $sql = "SELECT * FROM admins WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $admin_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        $admin = $result->fetch_assoc();
                    } else {
                        echo "No admin found.";
                        $conn->close();
                        exit;
                    }
                }
                ?>
                <h2>Old Information</h2>
                <p><strong>ID:</strong> <?php echo isset($admin['id']) ? $admin['id'] : ''; ?></p>
                <p><strong>Firstname:</strong> <?php echo isset($admin['firstname']) ? $admin['firstname'] : ''; ?></p>
                <p><strong>Lastname:</strong> <?php echo isset($admin['lastname']) ? $admin['lastname'] : ''; ?></p>
            </div>
        </div>
    <div class="card">
        <div class="content">
            <h2>Edit Admin</h2>
            <form method="post" action="update_admin.php?id=<?php echo isset($_GET['id']) ? $_GET['id'] : ''; ?>" enctype="multipart/form-data">
                <label for="username">Firstname:</label><br>
                <input type="text" id="username" name="username" value="<?php echo isset($admin['username']) ? $admin['username'] : ''; ?>"><br>
                <label for="username">Lastname:</label><br>
                <input type="text" id="username" name="username" value="<?php echo isset($admin['username']) ? $admin['username'] : ''; ?>"><br>
                <label for="password">Password:</label><br>
                <div class="password-container">
                    <input type="password" id="password" name="password">
                    <button type="button" id="togglePassword" onclick="togglePasswordVisibility()">&#128065;</button>
                </div>
                <br>
                <input type="submit" value="Update" onclick="return confirm('Are you sure you want to update this Admin?')">
                <button type="reset" onclick="return confirm('Are you sure you want to reset all this value?')">Reset</button>
                <div style="padding: 4px; width:auto; height:25px; background-color:#333; color:#f9f9f9;"><a href="/access/php/admin_page/admin_panal.php?id=<?php echo $_GET["adminid"]; ?>" target="_blank" rel="noopener noreferrer" style="color:#f9f9f9; font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bolder;">Return To Admin Page</a></div>

            </form>
        </div>
    </div>
</div>
<script>
    function togglePasswordVisibility() {
        var passwordField = document.getElementById("password");
        var toggleButton = document.getElementById("togglePassword");
        if (passwordField.type === "password") {
            passwordField.type = "text";
            toggleButton.innerHTML = "&#128064;";
        } else {
            passwordField.type = "password";
            toggleButton.innerHTML = "&#128065;";
        }
    }
</script>
</body>
</html>
