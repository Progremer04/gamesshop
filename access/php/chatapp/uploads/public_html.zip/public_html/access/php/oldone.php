<?php
// Sample database connection parameters
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name


// Create connection
$connection = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Assuming you have already established a database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve first name, last name, and password from the login form
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $password = $_POST['password'];

    // Prepare and execute SQL query to retrieve user info from admins table
    $queryAdmin = "SELECT id, password FROM admins WHERE firstname = ? AND lastname = ?";
    $statementAdmin = $connection->prepare($queryAdmin);
    $statementAdmin->bind_param("ss", $firstname, $lastname);
    $statementAdmin->execute();
    $resultAdmin = $statementAdmin->get_result();

    // Prepare and execute SQL query to retrieve user info from users table
    $queryUser = "SELECT id, password FROM users WHERE firstname = ? AND lastname = ?";
    $statementUser = $connection->prepare($queryUser);
    $statementUser->bind_param("ss", $firstname, $lastname);
    $statementUser->execute();
    $resultUser = $statementUser->get_result();

    if ($resultAdmin->num_rows > 0) {
        // Admin found, verify password
        $rowAdmin = $resultAdmin->fetch_assoc();
        $userId = $rowAdmin['id'];
        $hashedPassword = $rowAdmin['password'];
        $userType = "admin";
    } elseif ($resultUser->num_rows > 0) {
        // User found, verify password
        $rowUser = $resultUser->fetch_assoc();
        $userId = $rowUser['id'];
        $hashedPassword = $rowUser['password'];
        $userType = "user";
    } else {
        // Neither user nor admin found, handle error (e.g., display error message)
        $errorMessage = "User not found";
    }

    // Verify password
    if (isset($hashedPassword) && password_verify($password, $hashedPassword)) {
        // Password is correct, redirect user based on their user_type
        if ($userType == "admin") {
            // Redirect to admin panel
            header("Location: /access/php/admin_page/admin_index.php?id=$userId");
            exit();
        } else {
            // Redirect to user dashboard or homepage
            header("Location: /access/php/user_page/user_index.php?id=$userId");
            exit();
        }
    } else {
        // Incorrect password, handle error (e.g., display error message)
        $errorMessage = "Invalid password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">
    <!-- font google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kode+Mono:wght@400..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/access/css/navbar.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333; /* Text color */
        }
        
        main{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-self: center;
            width: 100%;
            height: 94vh;
        }
        
        .container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: #fff; /* White background color */
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 3;
        }
        
        h1 {
            text-align: center;
            color: #007bff; /* Header color */
        }
        
        form {
            text-align: center;
        }
        
        label {
            display: block;
        }
        
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        
        .password-container {
            position: relative;
        }
        
        #togglePassword {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            padding: 5px;
            background-color: transparent;
            border: none;
            cursor: pointer;
            font-size: 1.5em;
        }
        
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        input[type="submit"]:hover {
            background-color: #0056b3; 
        }
    </style>
</head>

<body>
    <header>
        <a href="/index.php"><div class="logo"><img src="/access/image/image.png" alt="الشعار"></div></a>
        <input type="checkbox" id="nav_check" hidden>
        <nav>
            <ul>
    <li><a href="/access/php/contact.php" target="_blank" rel="noopener noreferrer" class="active">Contact
                        us</a></li>
                <li><a href="/access/php/article.php" target="_blank" rel="noopener noreferrer">Les Article</a></li>
                <li><a href="/access/php/equivalence.php" target="_blank" rel="noopener noreferrer">Les éqivalance</a></li>
                <li><a href="/access/php/calcule.php" target="_blank" rel="noopener noreferrer">Les Calcules</a></li>
            </ul>
        </nav>
        <label for="nav_check" class="hamburger">
            <div></div>
            <div></div>
            <div></div>
        </label>
    </header>
    <main>
        <div class="container">
            <h1>تسجيل الدخول</h1>
            <form method="POST" action="/access/php/oldone.php">
                <label for="firstname">الاسم الأول:</label><br>
                <input type="text" id="firstname" name="firstname"><br>
                <label for="lastname">الاسم الأخير:</label><br>
                <input type="text" id="lastname" name="lastname"><br>
                <label for="password">كلمة المرور:</label><br>
                <div class="password-container">
                    <input type="password" id="password" name="password">
                    <button type="button" id="togglePassword" onclick="togglePasswordVisibility()">&#128065;</button>
                </div>
                <br>
                <input type="submit" value="تسجيل الدخول">
            </form>
        </div>
    </main>
    <script>
        function togglePasswordVisibility() {
            var passwordField = document.getElementById("password");
            var toggleButton = document.getElementById("togglePassword");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleButton.innerHTML = "&#128064;";
            } else {
                passwordField.type = "password";
                toggleButton.innerHTML = "&#128065;";
            }
        }
    </script>
</body>

</html>
