<?php
// Include your database connection file
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

$conn = new mysqli($servername, $firstname, $password, $database);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $password = $_POST["password"];
    
    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert data into the database
    $sql = "INSERT INTO admins (firstname,lastname,password) 
            VALUES ('$firstname','$lastname','$hashedPassword')";
    if (mysqli_query($conn, $sql)) {
        // Redirect to a success page or do something else after successful registration
        header("Location: /access/php/admin_page/add_admin.php");
        exit();
    } else {
        // Handle errors
        $error = "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Admin</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">
        <!-- font google -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Kode+Mono:wght@400..700&display=swap" rel="stylesheet">
     <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
        color: #333; /* Text color */
    }
    
    main{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-self: center;
    width: 100%;
    height: 100vh;
}
    .container {
        max-width: 400px;
        margin: 100px auto;
        padding: 20px;
        background-color: #fff; /* White background color */
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        z-index: 3;
    }
    
    h1 {
        text-align: center;
        color: #007bff; /* Header color */
    }
    
    form {
        text-align: center;
    }
    
    label {
        display: block;
    }
    
    input[type="text"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }
    
    .password-container {
        position: relative;
    }
    
    #togglePassword {
        position: absolute;
        top: 50%;
        right: 10px;
        transform: translateY(-50%);
        padding: 5px;
        background-color: transparent;
        border: none;
        cursor: pointer;
        font-size: 1.5em;
    }
    
    input[type="submit"] {
        width: 100%;
        padding: 10px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    
    input[type="submit"]:hover {
        background-color: #0056b3; 
    }
    .container:hover{
        background-color: #333;
        color: #fff;
    }
 
    </style>
    
</head>
<body>
   
    <main>
        <div class="container">
            <h1>Add Admin</h1>
            <form method="post" action="add_admin.php" enctype="multipart/form-data">
                <label for="firstname">Firstname</label><br>
                <input type="text" id="firstname" name="firstname"><br>
                <label for="lastname">Lastname</label><br>
                <input type="text" id="lastname" name="lastname"><br>
                <label for="password">password :</label><br>
                <div class="password-container">
                    <input type="password" id="password" name="password">
                    <button type="button" id="togglePassword" onclick="togglePasswordVisibility()">&#128065;</button>
                </div>
                <br>
                <input type="submit" value="Add Admin" onclick="return confirm('Are you sure you want to Add this Admin?')">
                <div style="padding: 4px; width:auto; height:25px; background-color:#333; color:#f9f9f9;"><a href="/access/php/admin_page/admin_panal.php" target="_blank" rel="noopener noreferrer" style="color:#f9f9f9; font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bolder;">Return To Admin Page</a></div>
            </form>
        </div>
    </main>
    <script>
        function togglePasswordVisibility() {
            var passwordField = document.getElementById("password");
            var toggleButton = document.getElementById("togglePassword");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleButton.innerHTML = "&#128064;";
            } else {
                passwordField.type = "password";
                toggleButton.innerHTML = "&#128065;";
            }
        }
    </script>
</body>
</html>
<?php 

?>