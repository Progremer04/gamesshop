<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us </title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">
    <link rel="stylesheet" href="access/css/style.css">
    <!-- font google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kode+Mono:wght@400..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/access/css/contact.css">
    <link rel="stylesheet" href="/access/css/navbar.css">
</head>

<body>
    <header>
    <a href="/index.php"><div class="logo"><img src="/access/image/image.png" alt="it's logo"></div></a>
        <input type="checkbox" id="nav_check" hidden>
        <nav>
            <ul>
               <li><a href="/access/php/contact.php" target="_blank" rel="noopener noreferrer" class="active">Contact
                        us</a></li>
                <li><a href="/access/php/article.php" target="_blank" rel="noopener noreferrer">Les Article</a></li>
                <li><a href="/access/php/equivalence.php" target="_blank" rel="noopener noreferrer">Les éqivalance</a></li>
                <li><a href="/access/php/calcule.php" target="_blank" rel="noopener noreferrer">Les Calcules</a></li>
            </ul>
        </nav>
        <label for="nav_check" class="hamburger">
            <div></div>
            <div></div>
            <div></div>
        </label>
    </header>
    <main>
    <div class="container">
        <h1>Contact Us</h1>
        <div id="options">
            <p class="question">Do you have an account?</p>
            <button class="btn" onclick="redirectToLogin()">Yes</button>
            <button class="btn btn-no" onclick="redirectToCreateAccount()">No</button>
        </div>
    </div>
    </main>
    <script>
        function redirectToLogin() {
            window.location.href = "oldone.php";
        }
        
        function redirectToCreateAccount() {
            window.location.href = "creating_new_account.php";
        }
    </script>
</body>
    </html>