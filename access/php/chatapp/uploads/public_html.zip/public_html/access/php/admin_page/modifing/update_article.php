<?php
error_reporting(E_ERROR | E_PARSE); // Suppress warnings but show other types of errors

$servername = "localhost";
$username = "id21942922_root";
$password = "Amine@2004";
$database = "id21942922_dietyour"; // Replace with your actual database name

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : null; // Get the admin ID from the URL parameter

// Handle form submission for updating an article
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    // Retrieve form data
    if(isset($_GET['id']) && !empty($_GET['id'])) {
        $article_id = $_GET['id'];
        $title = $_POST['title'];
        $content = $_POST['content'];
        $type = $_POST['type'];
        $place_main = $_POST['place_main'];

        // Update article details in the articles table
        $sql = "UPDATE articles SET title = ?, content = ?, type = ?, place_main = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssisi", $title, $content, $type, $place_main, $article_id);
        if ($stmt->execute()) {
            // Delete existing files and links associated with the article
            $delete_files_sql = "DELETE FROM article_files WHERE article_id = ?";
            $delete_files_stmt = $conn->prepare($delete_files_sql);
            $delete_files_stmt->bind_param("i", $article_id);
            $delete_files_stmt->execute();

            $delete_links_sql = "DELETE FROM article_links WHERE article_id = ?";
            $delete_links_stmt = $conn->prepare($delete_links_sql);
            $delete_links_stmt->bind_param("i", $article_id);
            $delete_links_stmt->execute();

            // Insert file paths or link URLs into the appropriate table
            if ($type == 2) {
                if (isset($_FILES['files']['name']) && !empty($_FILES['files']['name'][0])) {
                    $file_paths = [];
                    foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
                        $file_name = $_FILES['files']['name'][$key];
                        $file_path = '/access/php/admin_page/uploads/' . $file_name;
                        move_uploaded_file($tmp_name, $file_path);
                        $file_paths[] = $file_path;
                    }
                    foreach ($file_paths as $file_path) {
                        $insert_file_sql = "INSERT INTO article_files (article_id, file_path) VALUES (?, ?)";
                        $insert_file_stmt = $conn->prepare($insert_file_sql);
                        $insert_file_stmt->bind_param("is", $article_id, $file_path);
                        $insert_file_stmt->execute();
                    }
                }
            } elseif ($type == 3 && isset($_POST['links'])) {
                foreach ($_POST['links'] as $link_url) {
                    // Insert each link with the same article ID
                    $insert_link_sql = "INSERT INTO article_links (article_id, link_url) VALUES (?, ?)";
                    $insert_link_stmt = $conn->prepare($insert_link_sql);
                    $insert_link_stmt->bind_param("is", $article_id, $link_url);
                    $insert_link_stmt->execute();
                }
            }

            // // Fetch updated article details
            // $fetch_article_sql = "SELECT * FROM articles WHERE id = ?";
            // $fetch_article_stmt = $conn->prepare($fetch_article_sql);
            // $fetch_article_stmt->bind_param("i", $article_id);
            // $fetch_article_stmt->execute();
            // $result = $fetch_article_stmt->get_result();
            // if ($result->num_rows > 0) {
            //     $row = $result->fetch_assoc();
            //     // Display updated article details
            //     echo "<h2>Article Modified Successfully</h2>";
            //     echo "<p><strong>Title:</strong> " . $row['title'] . "</p>";
            //     echo "<p><strong>Content:</strong> " . $row['content'] . "</p>";
            //     echo "<p><strong>Type:</strong> " . $row['type'] . "</p>";
            //     echo "<p><strong>Place Main:</strong> " . $row['place_main'] . "</p>";

            //     // Fetch and display associated files if any
            //     $fetch_files_sql = "SELECT * FROM article_files WHERE article_id = ?";
            //     $fetch_files_stmt = $conn->prepare($fetch_files_sql);
            //     $fetch_files_stmt->bind_param("i", $article_id);
            //     $fetch_files_stmt->execute();
            //     $files_result = $fetch_files_stmt->get_result();
            //     if ($files_result->num_rows > 0) {
            //         echo "<p><strong>Associated Files:</strong></p>";
            //         echo "<ul>";
            //         while ($file_row = $files_result->fetch_assoc()) {
            //             echo "<li>" . $file_row['file_path'] . "</li>";
            //         }
            //         echo "</ul>";
            //     }

            //     // Fetch and display associated links if any
            //     $fetch_links_sql = "SELECT * FROM article_links WHERE article_id = ?";
            //     $fetch_links_stmt = $conn->prepare($fetch_links_sql);
            //     $fetch_links_stmt->bind_param("i", $article_id);
            //     $fetch_links_stmt->execute();
            //     $links_result = $fetch_links_stmt->get_result();
            //     if ($links_result->num_rows > 0) {
            //         echo "<p><strong>Associated Links:</strong></p>";
            //         echo "<ul>";
            //         while ($link_row = $links_result->fetch_assoc()) {
            //             echo "<li>" . $link_row['link_url'] . "</li>";
            //         }
            //         echo "</ul>";
            //     }
            // } else {
            //     echo "Error fetching updated article details.";
            // }
        } else {
            echo "Error updating article: " . $conn->error;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Article</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease forwards;
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
            animation: slideInDown 0.5s ease forwards;
        }

        form {
            text-align: left;
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea,
        select,
        input[type="file"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .dynamic-inputs {
            display: none;
        }

        .fadeIn {
            animation: fadeIn 0.5s ease forwards;
        }

        #linksContainer {
            margin-bottom: 20px;
        }

        #addLink {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 8px 12px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        #addLink:hover {
            background-color: #0056b3;
        }

        .preview-container {
            margin-bottom: 20px;
        }

        .preview-container img,
        .preview-container .file-name {
            display: block;
            margin-bottom: 5px;
        }

        .preview-container .delete-button {
            color: red;
            cursor: pointer;
            display: inline-block;
            margin-left: 10px;
        }

        .preview-container .delete-button:hover {
            text-decoration: underline;
        }

        .file-preview {
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            display: inline-block;
        }

        @media screen and (max-width: 600px) {
            form {
                padding: 0 20px;
            }

            input[type="text"],
            textarea,
            select,
            input[type="file"] {
                width: calc(100% - 20px);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        button[type="submit"],
        button[type="reset"] {
            width: 48%;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        button[type="submit"]:hover,
        button[type="reset"]:hover {
            background-color: #0056b3;
        }

        #addLink {
            width: 48%;
            padding: 20px;
            margin-top: auto;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Courier New', Courier, monospace;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        /* Card Styles */
        .card {
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 10px;
            color: #333;
        }

        .card p {
            font-size: 16px;
            margin-bottom: 15px;
            color: #666;
        }

        .card .label {
            font-weight: bold;
        }

        .card .data {
            margin-left: 10px;
        }

        .card .data ul {
            padding: 0;
        }

        .card .data li {
            list-style: none;
            margin-bottom: 5px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            /* Adjust the width of each column as needed */
            gap: 20px;
            /* Adjust the gap between cards */
        }

        .grid .card {
            background-color: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .grid .card .content {
            padding: 20px;
        }

        .grid .card p {
            margin-bottom: 10px;
        }

        .grid .card textarea {
            width: 100%;
            min-height: 100px;
            resize: vertical;
            margin-bottom: 10px;
        }

        .grid .card img {
            max-width: 100%;
            height: auto;
            margin-bottom: 10px;
        }

        .grid .card ul {
            list-style-type: disc;
            padding-left: 20px;
        }

        .grid .card ul li {
            margin-bottom: 5px;
        }

        .pagination {
            margin-top: 20px;
        }

        .pagination a {
            text-decoration: none;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 5px;
            color: #333;
        }

        .pagination a.active {
            background-color: #ffd700;
            color: #fff;
            border: 1px solid #ffd700;
        }

        .video-container {
            position: relative;
            width: 100%;
            padding-bottom: 56.25%;
            /* 16:9 aspect ratio (height/width) */
            overflow: hidden;
        }

        .video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .contain_two_btn {
            display: flex;
            justify-content: space-between;
        }

        .contain_two_btn a {
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .delete-btn {
            background-color: #FF6347;
            /* Tomato */
            color: #fff;
        }

        .modify-btn {
            background-color: #4169E1;
            /* Royal Blue */
            color: #fff;
        }

        .contain_two_btn a:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .delete-btn:hover {
            background-color: #CD5C5C;
            /* Indian Red */
        }

        .modify-btn:hover {
            background-color: #6495ED;
            /* Cornflower Blue */
        }

        .contain_two_btn a:active {
            transform: translateY(0);
            box-shadow: none;
        }

        @media only screen and (max-width: 480px) {
            .contain_two_btn {
                flex-direction: column;
                align-items: stretch;
            }

            .contain_two_btn a {
                margin-bottom: 10px;
            }
        }

        .card {
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, color 0.3s;
        }

        .card:hover {
            background-color: #333;
            color: #ffffff;
        }
        }

        .card {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 20px;
        }


        .mb-2 {
            margin-bottom: 2px;
        }

        .list-disc {
            list-style-type: disc;
        }

        .pl-5 {
            padding-left: 20px;
        }

        .contain_two_btn {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>

<body>
    <div class="grid">
       
        <?php
        // Connect to your database here
        $conn = new mysqli($servername, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $article_id = $_GET['id']; // Assuming you're getting the article ID from the URL
        
        $sql = "SELECT * FROM articles WHERE id='$article_id'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='grid'>";
                echo "<div class='card'>";
                echo "<div class='content'>";
                echo "<p><strong>Old Information</strong></p>";
                echo "<p><strong>ID:</strong> " . $row["id"] . "</p>";
                echo "<p><strong>Title:</strong> " . $row["title"] . "</p>";
                echo "<p><strong>Content:</strong> ";
                echo "<textarea cols='30' rows='10' readonly>" . $row["content"] . "</textarea>";
                // Check article type
                if ($row["type"] == 2) {
                    echo "<p><strong>Photos :</strong></p>";
                    // Article type 2 with images
                    $sql_images = "SELECT * FROM article_files WHERE article_id=" . $row["id"];
                    $result_images = $conn->query($sql_images);
                    if ($result_images->num_rows > 0) {
                        while ($image_row = $result_images->fetch_assoc()) {
                            echo "<img src='" . $image_row["file_path"] . "' class='mb-2'>";
                        }
                    }
                } elseif ($row["type"] == 3) {
                    // Article type 3 with links
                    $sql_links = "SELECT * FROM article_links WHERE article_id=" . $row["id"];
                    $result_links = $conn->query($sql_links);
                    $i = 1;
                    if ($result_links->num_rows > 0) {
                        echo "<p><strong>Links :</strong></p>";
                        echo "<ul class='list-disc pl-5'>";
                        while ($link_row = $result_links->fetch_assoc()) {
                            $link = $link_row["link_url"];
                            echo "<li>";
                            echo "Link {$i}: <a href='$link' class='text-blue-500' target='_blank'>link {$i}</a>";
                            echo "</li>";
                            $i++;
                        }
                        echo "</ul>";
                    }
                }

                echo "<ul>";
                echo "<li><strong>Type:</strong> " . $row["type"] . "</li>";
                $string = ($row["place_main"] == "Phsiopath") ? "Article Showing In Main" : "Article showing in Article page";
                echo "<li><strong>Main Place:</strong> " . $string . "</li>";
                echo "<li><strong>Created At:</strong> " . $row["created_at"] . "</li>";
                echo "<li><strong>Updated At:</strong> " . $row["updated_at"] . "</li>";
                echo "</ul>";
                echo "<div class='contain_two_btn'>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "0 results";
        }
        $conn->close();
        ?>

    </div>

    <div class="container">


        <!-- Form for adding or updating an article -->
        <h2>Update Article</h2>
        <form method="post" enctype="multipart/form-data">
            <!-- Input fields for article details -->
            <!-- Title -->
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required><br>

            <!-- Content -->
            <label for="content">Content:</label>
            <textarea id="content" name="content" rows="4" required></textarea><br>

            <!-- Type -->
            <label for="type">Type:</label>
            <select id="type" name="type" required>
                <option value="1">Word Only</option>
                <option value="2">Word with Photos</option>
                <option value="3">Link with Word</option>
            </select><br>

            <!-- Place Main -->
            <label for="place_main">Place Main:</label>
            <select id="place_main" name="place_main" required>
                <option value="Phsiopath">Phsiopath : The Article You Gonna Find Him In Main Page</option>
                <option value="article">Article : The Article You Gonna Find Him In Article Page</option>
            </select><br>

            <!-- Dynamic inputs for files or links based on the selected type -->
            <div class="dynamic-inputs" id="fileUpload">
                <!-- File Upload -->
                <label for="files">Upload Files:</label>
                <input type="file" id="files" name="files[]" multiple><br>
                <div id="filePreview" class="preview-container"></div>
            </div>
            <div class="dynamic-inputs" id="linkInput">
                <!-- Links Input -->
                <label for="links">Enter Links:</label>
                <div id="linksContainer"></div>
                <button type="button" id="addLink">Add Link</button>
            </div>

            <!-- Submit button -->
            <button type="submit" name="update" onclick="return confirm('Are you sure you want to update this Article ?')">Update Article</button>

            <!-- Reset button -->
            <button type="reset">Reset</button>
            <div style="padding: 4px; width:auto; height:25px; background-color:#333; color:#f9f9f9;">
    <a href="/access/php/admin_page/admin_panal.php?id=<?php echo $admin_id;?>" target="_blank" rel="noopener noreferrer" style="color:#f9f9f9; font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bolder;">Return To Admin Page</a>
</div>
        </form>
    </div>

    <!-- JavaScript code for handling dynamic inputs and form submission -->
    <script>
        document.getElementById('type').addEventListener('change', function () {
            var type = this.value;
            var fileUpload = document.getElementById('fileUpload');
            var linkInput = document.getElementById('linkInput');
            if (type == 2) {
                fileUpload.style.display = 'block';
                linkInput.style.display = 'none';
                fileUpload.classList.add('fadeIn');
                linkInput.classList.remove('fadeIn');
            } else if (type == 3) {
                fileUpload.style.display = 'none';
                linkInput.style.display = 'block';
                fileUpload.classList.remove('fadeIn');
                linkInput.classList.add('fadeIn');
            } else {
                fileUpload.style.display = 'none';
                linkInput.style.display = 'none';
                fileUpload.classList.remove('fadeIn');
                linkInput.classList.remove('fadeIn');
            }
        });

        document.getElementById('files').addEventListener('change', function () {
            var files = this.files;
            var filePreview = document.getElementById('filePreview');
            filePreview.innerHTML = '';
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var fileDiv = document.createElement('div');
                fileDiv.classList.add('file-preview');
                var fileName = document.createElement('span');
                fileName.classList.add('file-name');
                fileName.textContent = file.name;
                var deleteButton = document.createElement('span'); // Define deleteButton here
                deleteButton.classList.add('delete-button');
                deleteButton.textContent = 'Delete';
                deleteButton.addEventListener('click', function () {
                    // Remove the parent element of the delete button
                    this.parentNode.remove();
                });
                var br = document.createElement('br');
                fileDiv.appendChild(fileName);
                fileDiv.appendChild(deleteButton);
                filePreview.appendChild(fileDiv);
                filePreview.appendChild(br);
            }
        });

        document.getElementById('addLink').addEventListener('click', function () {
            var linksContainer = document.getElementById('linksContainer');
            var linkInput = document.createElement('input');
            linkInput.type = 'text';
            linkInput.name = 'links[]';
            linkInput.placeholder = 'Enter Link URL';
            var br = document.createElement('br');
            linksContainer.appendChild(linkInput);
            linksContainer.appendChild(br);
        });

        // Reset button functionality
        document.querySelector('input[type="reset"]').addEventListener('click', function () {
            // Clear file preview
            document.getElementById('filePreview').innerHTML = '';

            // Clear links container
            document.getElementById('linksContainer').innerHTML = '';
        });
    </script>


</body>

</html>