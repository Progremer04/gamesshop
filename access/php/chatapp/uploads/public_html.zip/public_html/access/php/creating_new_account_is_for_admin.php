<?php
// Include your database connection file
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

$conn = new mysqli($servername, $username, $password, $database);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $age = $_POST["age"];
    $birthday = $_POST["brithday"]; // Fixed typo in variable name
    $gender = $_POST["gender"];
    $city = $_POST["city"];
    $phone = $_POST["phone"];
    $weight=$_POST["weight"];
    $height=$_POST["height"];
    $password = $_POST["password"];
    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert data into the database
    $sql = "INSERT INTO users (password, firstName, lastName, age, birthday, gender, city, phone,weight,length) 
            VALUES ('$hashedPassword', '$firstName', '$lastName', '$age', '$birthday', '$gender', '$city', '$phone','$weight','$height')";
    if (mysqli_query($conn, $sql)) {
        // Redirect to a success page or do something else after successful registration
        header("Location: /access/php/admin_page/admin_panal.php");
        exit();
    } else {
        // Handle errors
        $error = "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">

    <title>  انشاء الحساب للمستخدم بأستخدام  مسؤول</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: right;
            /* Align text to the right */
        }

        body::before {
            content: "";
            background-image: url("/access/image/contact.jpg");
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            filter: blur(5px);
            z-index: -1;
        }

        .container {
            position: relative;
            z-index: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        #multiStepForm {
            max-width: 600px;
            width: 100%;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
            /* Semi-transparent white background */
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .step {
            display: none;
        }

        .step:first-child {
            display: block;
        }

        h2 {
            margin-bottom: 20px;
        }

        input,
        button,
        select {
            /* Adjust select element style */
            display: block;
            width: calc(100% - 20px);
            /* Adjusted width to account for padding */
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            /* Include padding and border in the width calculation */
            transition: opacity 0.3s ease;
            /* Add opacity transition */
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            font-size: 12px;
        }

        @media screen and (max-width: 600px) {
            #multiStepForm {
                padding: 10px;
            }
        }

        .fade-in {
            opacity: 1;
        }

        .fade-out {
            opacity: 0;
            pointer-events: none;
            /* Disable pointer events while fading out */
        }

        #togglePassword,
        #togglePassword1 {
            color: black;
            transform: translateX(43%);
            margin-top: -45px;
            right: 50px;
            padding: 5px;
            background-color: transparent;
            border: none;
            cursor: pointer;
            font-size: 1.5em;
            z-index: 5;
            /* Ensure it's above other elements */
            transition: color 0.3s ease;
            /* Add transition for color change */
        }

        #togglePassword:hover,
        #togglePassword1:hover {
            color: #007bff;
            /* Change color on hover */
        }
    </style>
</head>

<body>
    <div class="container">
        <form method="post" action="creating_new_account.php" id="multiStepForm">
            <div class="step fade-in" id="step1">
                <h2>خطوة الأولى: معلومات الشخصية</h2>
                <input type="text" id="firstName" name="firstName" placeholder="الاسم" required>
                <input type="text" id="lastName" name="lastName" placeholder="لقب" required>
                <span id="step1Error" class="error"></span>
                <button type="button" onclick="nextStep(1)">تالي</button>
                <button type="reset">حذف جميع الإدخالات</button>

            </div>
            <div class="step" id="step2">
                <h2>خطوة الثانية: عمر وتاريخ الميلاد وجنسك</h2>
                <input type="number" id="age" name="age" placeholder="عمرك" required>
                <input type="date" id="brithday" name="brithday" placeholder="تاريخ ميلادك" required>
                <select id="gender" name="gender" required>
                    <option value="" disabled selected>اختر الجنس</option>
                    <option value="ذكر">ذكر</option>
                    <option value="أنثى">أنثى</option>
                </select>
                <span id="step2Error" class="error"></span>
                <button type="button" onclick="prevStep(2)">سابق</button>
                <button type="button" onclick="nextStep(2)">تالي</button>
                <button type="reset">حذف جميع الإدخالات</button>

            </div>
            <div class="step" id="step3">
                <h2>خطوة الثالثة: الولاية و رقم الهاتف </h2>
                <input type="text" id="city" name="city" placeholder="الولاية" required>
                <input type="tel" id="phone" name="phone" placeholder="رقم هاتفك" required>
                <span id="step3Error" class="error"></span>
                <button type="button" onclick="prevStep(3)">سابق</button>
                <button type="button" onclick="nextStep(3)">تالي</button>
                <button type="reset">حذف جميع الإدخالات</button>

            </div>
            <div class="step" id="step4">
                <h2>خطوة الرابعة: طولك و وزنك</h2>
                <input type="number" id="weight" name="weight" placeholder="وزنك (كغ)" step="0.01" required>
                <input type="number" id="height" name="height" placeholder="طولك (متر)" step="0.01" required>

                <span id="step2Error" class="error"></span>
                <button type="button" onclick="prevStep(4)">سابق</button>
                <button type="button" onclick="nextStep(4)">تالي</button>
                <button type="reset">حذف جميع الإدخالات</button>

            </div>
            <div class="step" id="step5">
                <h2>خطوة الأخيرة: إعداد الحساب</h2>
                <input type="password" id="password" name="password" placeholder="كلمة المرور" required>
                <button type="button" id="togglePassword" onclick="togglePasswordVisibility()">&#128065;</button>
                <input type="password" id="confirmPassword" name="confirmPassword" placeholder="تأكيد كلمة المرور"
                    required>
                <button type="button" id="togglePassword1" onclick="togglePasswordVisibility1()">&#128065;</button>
                <span id="step4Error" class="error"></span>
                <button type="button" onclick="prevStep(5)">سابق</button>
                <button type="reset">حذف جميع الإدخالات</button>
                <button type="submit">تسجيل</button>
            </div>
        </form>

        <div style="padding: 4px; width:auto; height:25px; background-color:#333; color:#f9f9f9;"><a href="/access/php/admin_page/admin_panal.php?id=<?php echo $_GET["adminid"];?>" target="_blank" rel="noopener noreferrer" style="color:#f9f9f9; font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bolder;">Return To Admin Page</a></div>
    </div>

    <script>
        let currentStep = 1;
        const totalSteps = document.querySelectorAll('.step').length;

        function nextStep(step) {
            let valid = true;
            const currentStepInputs = document.querySelectorAll(`#step${step} input, #step${step} select`);
            currentStepInputs.forEach(input => {
                if (!input.checkValidity()) {
                    valid = false;
                    const errorSpan = document.getElementById(`step${step}Error`);
                    errorSpan.textContent = 'يرجى ملء جميع العلومات.';
                }
            });
            if (valid) {
                document.getElementById(`step${currentStep}`).classList.remove('fade-in');
                document.getElementById(`step${currentStep}`).classList.add('fade-out');
                setTimeout(() => {
                    document.getElementById(`step${currentStep}`).style.display = 'none';
                    currentStep = step + 1;
                    document.getElementById(`step${currentStep}`).style.display = 'block';
                    document.getElementById(`step${currentStep}`).classList.remove('fade-out');
                    document.getElementById(`step${currentStep}`).classList.add('fade-in');
                }, 300); // Wait for fade-out transition before changing display and fading in the next step
            }
        }

        function prevStep(step) {
            document.getElementById(`step${currentStep}`).classList.remove('fade-in');
            document.getElementById(`step${currentStep}`).classList.add('fade-out');
            setTimeout(() => {
                document.getElementById(`step${currentStep}`).style.display = 'none';
                currentStep = step - 1;
                document.getElementById(`step${currentStep}`).style.display = 'block';
                document.getElementById(`step${currentStep}`).classList.remove('fade-out');
                document.getElementById(`step${currentStep}`).classList.add('fade-in');
            }, 300); // Wait for fade-out transition before changing display and fading in the previous step
        }

        function togglePasswordVisibility() {
            var passwordField = document.getElementById("password");
            var toggleButton = document.getElementById("togglePassword");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleButton.innerHTML = "&#128064;";
            } else {
                passwordField.type = "password";
                toggleButton.innerHTML = "&#128065;";
            }
        }

        function togglePasswordVisibility1() {
            var passwordField = document.getElementById("confirmPassword");
            var toggleButton = document.getElementById("togglePassword1");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleButton.innerHTML = "&#128064;";
            } else {
                passwordField.type = "password";
                toggleButton.innerHTML = "&#128065;";
            }
        }
    </script>
</body>

</html>