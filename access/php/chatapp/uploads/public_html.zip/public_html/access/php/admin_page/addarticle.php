<?php
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

// Connect to the database
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$id = isset($_GET['admin_id']) ? $_GET['admin_id'] : null;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Article</title>
    <link rel="shortcut icon" href="/access/image/image.png" type="image/x-icon">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease forwards;
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
            animation: slideInDown 0.5s ease forwards;
        }

        form {
            text-align: left;
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea,
        select,
        input[type="file"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .dynamic-inputs {
            display: none;
        }

        .fadeIn {
            animation: fadeIn 0.5s ease forwards;
        }

        #linksContainer {
            margin-bottom: 20px;
        }

        #addLink {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 8px 12px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        #addLink:hover {
            background-color: #0056b3;
        }

        .preview-container {
            margin-bottom: 20px;
        }

        .preview-container img,
        .preview-container .file-name {
            display: block;
            margin-bottom: 5px;
        }

        .preview-container .delete-button {
            color: red;
            cursor: pointer;
            display: inline-block;
            margin-left: 10px;
        }

        .preview-container .delete-button:hover {
            text-decoration: underline;
        }

        .file-preview {
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            display: inline-block;
        }

        @media screen and (max-width: 600px) {
            form {
                padding: 0 20px;
            }

            input[type="text"],
            textarea,
            select,
            input[type="file"] {
                width: calc(100% - 20px);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }
        button[type="submit"],
        button[type="reset"] {
            width: 48%;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        button[type="submit"]:hover,
        button[type="reset"]:hover {
            background-color: #0056b3;
        }
        #addLink{
            width: 48%;
            padding: 20px;
            margin-top: auto;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Courier New', Courier, monospace;
            transition: background-color 0.3s;
            font-size: 16px;
        }

    </style>
</head>

<body>
    <div class="container">
        <h2>Add Article</h2>
        <form method="post" enctype="multipart/form-data">
    <label for="title">Title:</label>
    <input type="text" id="title" name="title" required><br>
    <label for="content">Content:</label>
    <textarea id="content" name="content" rows="4" required></textarea><br>
    <label for="type">Type:</label>
    <select id="type" name="type" required>
        <option value="1">Word Only</option>
        <option value="2">Word with Photos</option>
        <option value="3">Link with Word</option>
    </select><br>
    <label for="place_main">Place Main:</label>
    <select id="place_main" name="place_main" required>
        <option value="Phsiopath">Phsiopath : The Article You Gonna Find Him In Main Page</option>
        <option value="article">Article :  The Article You Gonna Find Him In Artilce  Page</option>
    </select><br>
    <div class="dynamic-inputs" id="fileUpload">
        <label for="files">Upload Files:</label>
        <input type="file" id="files" name="files[]" multiple><br>
        <div id="filePreview" class="preview-container"></div>
    </div>
    <div class="dynamic-inputs" id="linkInput">
        <label for="links">Enter Links:</label>
        <div id="linksContainer"></div>
        <button type="button" id="addLink">Add Link</button>
    </div>

    <button type="submit">Submit</button>
    <button type="reset">reset</button>
    <div style="padding: 4px; width:auto; height:25px; background-color:#333; color:#f9f9f9;"><a href="/access/php/admin_page/admin_panal.php?id=<?php echo $_GET["admin_id"];?>" target="_blank" rel="noopener noreferrer" style="color:#f9f9f9; font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bolder;">Return To Admin Page</a></div>

</form>

    </div>

    <script>
    document.getElementById('type').addEventListener('change', function () {
        var type = this.value;
        var fileUpload = document.getElementById('fileUpload');
        var linkInput = document.getElementById('linkInput');
        if (type == 2) {
            fileUpload.style.display = 'block';
            linkInput.style.display = 'none';
            fileUpload.classList.add('fadeIn');
            linkInput.classList.remove('fadeIn');
        } else if (type == 3) {
            fileUpload.style.display = 'none';
            linkInput.style.display = 'block';
            fileUpload.classList.remove('fadeIn');
            linkInput.classList.add('fadeIn');
        } else {
            fileUpload.style.display = 'none';
            linkInput.style.display = 'none';
            fileUpload.classList.remove('fadeIn');
            linkInput.classList.remove('fadeIn');
        }
    });

    document.getElementById('files').addEventListener('change', function () {
        var files = this.files;
        var filePreview = document.getElementById('filePreview');
        filePreview.innerHTML = '';
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var fileDiv = document.createElement('div');
            fileDiv.classList.add('file-preview');
            var fileName = document.createElement('span');
            fileName.classList.add('file-name');
            fileName.textContent = file.name;
            var br = document.createElement('br');
            fileDiv.appendChild(fileName);
            filePreview.appendChild(fileDiv);
            filePreview.appendChild(br);
        }
    });

    document.getElementById('addLink').addEventListener('click', function () {
        var linksContainer = document.getElementById('linksContainer');
        var linkInput = document.createElement('input');
        linkInput.type = 'text';
        linkInput.name = 'links[]';
        linkInput.placeholder = 'Enter Link URL';
        var br = document.createElement('br');
        linksContainer.appendChild(linkInput);
        linksContainer.appendChild(br);
    });

    // Reset button functionality
    document.querySelector('input[type="reset"]').addEventListener('click', function () {
        // Clear file preview
        document.getElementById('filePreview').innerHTML = '';

        // Clear links container
        document.getElementById('linksContainer').innerHTML = '';
    });
</script>


</body>

</html>


<?php
    // Establish a connection to the MySQL database
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name


    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $title = $_POST['title'];
    $content = $_POST['content'];
    $type = $_POST['type'];
    $place_main = $_POST['place_main'];

    // Prepare the SQL statement with placeholders
    $sql = "INSERT INTO articles (title, content, type, place_main) VALUES (?, ?, ?, ?)";
    
    // Create a prepared statement
    $stmt = $conn->prepare($sql);

    // Bind the parameters
    $stmt->bind_param("ssis", $title, $content, $type, $place_main);

    // Execute the statement
    if ($stmt->execute()) {
        // Get the ID of the inserted record
        $article_id = $stmt->insert_id;

        // Insert file paths or link URLs into the appropriate table
        if ($type == 2 && isset($_FILES['files'])) {
            $file_paths = [];
            foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
                $file_name = $_FILES['files']['name'][$key];
                $uploads_directory = 'uploads/';
                $file_path = $uploads_directory . $file_name;
                move_uploaded_file($tmp_name, $file_path);
                $file_paths[] = $file_path;
            }
            foreach ($file_paths as $file_path) {
                // Prepare the SQL statement for file insertion
                $sql = "INSERT INTO article_files (article_id, file_path) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("is", $article_id, $file_path);
                $stmt->execute();
            }
        } elseif ($type == 3 && isset($_POST['links'])) {
            // Loop through each link and insert it into the database
            foreach ($_POST['links'] as $link_url) {
                if (!empty($link_url)) {
                    // Prepare the SQL statement for link insertion
                    $sql = "INSERT INTO article_links (article_id, link_url) VALUES (?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("is", $article_id, $link_url);
                    $stmt->execute();
                }
            }
        }

        echo "Article added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
    $conn->close();
}
?>