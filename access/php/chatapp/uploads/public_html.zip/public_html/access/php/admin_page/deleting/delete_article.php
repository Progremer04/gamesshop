<?php
// Check if the ID parameter is set and not empty
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Include database connection
    
    // Connect to your database here
        $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Prepare a DELETE statement for article_files
        $sql_files = "DELETE FROM article_files WHERE article_id = ?";
        $stmt_files = $conn->prepare($sql_files);
        $stmt_files->bind_param("i", $article_id);

        // Prepare a DELETE statement for article_links
        $sql_links = "DELETE FROM article_links WHERE article_id = ?";
        $stmt_links = $conn->prepare($sql_links);
        $stmt_links->bind_param("i", $article_id);

        // Prepare a DELETE statement for articles
        $sql_articles = "DELETE FROM articles WHERE id = ?";
        $stmt_articles = $conn->prepare($sql_articles);
        $stmt_articles->bind_param("i", $article_id);

        // Set parameter for all statements
        $article_id = $_GET['id'];

        // Execute the statements
        $stmt_files->execute();
        $stmt_links->execute();
        $stmt_articles->execute();

        // Commit the transaction
        $conn->commit();
        $admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : ''; // Get the admin ID from the URL parameter

        // Redirect back to the admin page after successful deletion
        header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);
        exit();
    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $conn->rollback();

        // Display an error message
        echo "Error deleting record: " . $e->getMessage();
    }

    // Close statements
    $stmt_files->close();
    $stmt_links->close();
    $stmt_articles->close();

    // Close connection
    $conn->close();
} else {
    // If no ID parameter is provided, redirect to admin page
    header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);
    exit();
}
?>
