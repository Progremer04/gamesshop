<?php
// Sample database connection
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : ''; // Get the admin ID from the URL parameter

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id'])){
    // Collect form data
    $id = isset($_GET['id']) ? $_GET['id'] : null;
    $firstName = isset($_POST['firstName']) ? $_POST['firstName'] : null;
    $lastName = isset($_POST['lastName']) ? $_POST['lastName'] : null;
    $age = isset($_POST['age']) ? $_POST['age'] : null;
    $birthday = isset($_POST['birthday']) ? $_POST['birthday'] : null;
    $gender = isset($_POST['gender']) ? $_POST['gender'] : null;
    $city = isset($_POST['city']) ? $_POST['city'] : null;
    $phone = isset($_POST['phone']) ? $_POST['phone'] : null;

    // Update user data
    $sql = "UPDATE users SET firstName=?, lastName=?, age=?, birthday=?, gender=?, city=?, phone=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssissssi", $firstName, $lastName, $age, $birthday, $gender, $city, $phone, $id);

    if ($stmt->execute() === TRUE) {
        echo "User data updated successfully";
    } else {
        echo "Error updating user data: " . $conn->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/access/image/image.png" type="image/png">

    <title>Edit User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease forwards;
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
            animation: slideInDown 0.5s ease forwards;
        }

        .card {
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, color 0.3s;
        }

        .card:hover {
            background-color: #333;
            color: #ffffff;
        }

        form {
            text-align: left;
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="number"],
        select {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"], button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            border: 3px solid #000;
            transition: all 0.5s;
            background-color: brown;
            color: #fff;
            font-size: larger;
        }

        button {
            margin-top: 3px;
        }

        button:hover {
            border: 3px solid #000;
            transition: all 0.5s;
            background-color: #333;
            color: #fff;
            font-size: larger;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Edit User</h2>
        <div class="card">
            <div class="content">

                <?php
                // Sample database connection
                      $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

                $conn = new mysqli($servername, $username, $password, $database);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $user = null; // Initialize $user variable

                // Check if the user ID is provided in the URL
                if (isset($_GET['id'])) {
                    // Retrieve the user ID from the URL
                    $user_id = $_GET['id'];

                    // Fetch user information based on the provided ID
                    $sql = "SELECT * FROM users WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        $user = $result->fetch_assoc();
                    } else {
                        echo "No user found.";
                        $conn->close();
                        exit;
                    }
                }
                ?>
                <h3>Old Information</h3>
                <p><strong>ID:</strong> <?php echo isset($user['id']) ? $user['id'] : ''; ?></p>
                <p><strong>First Name:</strong> <?php echo isset($user['firstName']) ? $user['firstName'] : ''; ?></p>
                <p><strong>Last Name:</strong> <?php echo isset($user['lastName']) ? $user['lastName'] : ''; ?></p>
                <p><strong>Age:</strong> <?php echo isset($user['age']) ? $user['age'] : ''; ?></p>
                <p><strong>Birthday:</strong> <?php echo isset($user['birthday']) ? $user['birthday'] : ''; ?></p>
                <p><strong>Gender:</strong> <?php echo isset($user['gender']) ? $user['gender'] : ''; ?></p>
                <p><strong>City:</strong> <?php echo isset($user['city']) ? $user['city'] : ''; ?></p>
                <p><strong>Phone:</strong> <?php echo isset($user['phone']) ? $user['phone'] : ''; ?></p>
            </div>
        </div>
        <form method="post" action="update_user.php?id=<?php echo isset($user['id']) ? $user['id'] : ''; ?>">
            <label for="firstName">First Name:</label>
            <input type="text" id="firstName" name="firstName" value="<?php echo isset($user['firstName']) ? $user['firstName'] : ''; ?>" required><br>

            <label for="lastName">Last Name:</label>
            <input type="text" id="lastName" name="lastName" value="<?php echo isset($user['lastName']) ? $user['lastName'] : ''; ?>" required><br>

            <label for="age">Age:</label>
            <input type="number" id="age" name="age" value="<?php echo isset($user['age']) ? $user['age'] : ''; ?>"><br>

            <label for="birthday">Birthday:</label>
            <input type="date" id="birthday" name="birthday" value="<?php echo isset($user['birthday']) ? $user['birthday'] : ''; ?>"><br>

            <label for="gender">Gender:</label>
            <select id="gender" name="gender">
                <option value="Male" <?php echo (isset($user['gender']) && $user['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo (isset($user['gender']) && $user['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                <option value="Other" <?php echo (isset($user['gender']) && $user['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
            </select><br>

            <label for="city">City:</label>
            <input type="text" id="city" name="city" value="<?php echo isset($user['city']) ? $user['city'] : ''; ?>"><br>

            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" value="<?php echo isset($user['phone']) ? $user['phone'] : ''; ?>"><br>

            <input type="submit" value="Update" onclick="return confirm('Are you sure you want to update this User?')">
            <button type="reset" onclick="return confirm('Are you sure you want to reset all this value?')">Reset</button>
            <div style="padding: 4px; display: inline-block; background-color: #333; color: #f9f9f9;">
    <a href="/access/php/admin_page/admin_panal.php?id=<?php echo $_GET['adminid']; ?>" target="_blank" rel="noopener noreferrer" style="text-decoration: none; color: #f9f9f9; font-family: Georgia, 'Times New Roman', Times, serif; font-weight: bold;">Return To Admin Page</a>
</div>

        </form>
    </div>
</body>

</html>
