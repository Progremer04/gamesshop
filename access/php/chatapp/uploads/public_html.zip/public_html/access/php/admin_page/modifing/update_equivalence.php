<?php
error_reporting(E_ERROR | E_PARSE); // Suppress warnings but show other types of errors

       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name


$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : ''; // Get the admin ID from the URL parameter


// Handle form submission for updating an article
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    // Retrieve form data
    if(isset($_GET['id']) && !empty($_GET['id'])) {
        $article_id = $_GET['id'];
        $title = $_POST['title'];
        $content = $_POST['content'];

        // Update article details in the articles table
        $sql = "UPDATE equivalence SET title = ?, description = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $title, $content, $article_id);
        if ($stmt->execute()) {
            // Delete existing files associated with the article
            $delete_files_sql = "DELETE FROM equivalence_images WHERE equivalence_id = ?";
            $delete_files_stmt = $conn->prepare($delete_files_sql);
            $delete_files_stmt->bind_param("i", $article_id);
            $delete_files_stmt->execute();

            // Insert file paths into the appropriate table
            if (isset($_FILES['files']['name']) && !empty($_FILES['files']['name'][0])) {
                $file_paths = [];
                foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
                    $file_name = $_FILES['files']['name'][$key];
                    $file_path = '/access/php/admin_page/uploads/' . $file_name;
                    move_uploaded_file($tmp_name, $file_path);
                    $file_paths[] = $file_path;
                }
                foreach ($file_paths as $file_path) {
                    $insert_file_sql = "INSERT INTO equivalence_images (equivalence_id, image_path) VALUES (?, ?)";
                    $insert_file_stmt = $conn->prepare($insert_file_sql);
                    $insert_file_stmt->bind_param("is", $article_id, $file_path);
                    $insert_file_stmt->execute();
                }
            }
            echo "Article Updated Successfully";
        } else {
            echo "Error updating article: " . $conn->error;
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/access/image/image.png" type="image/png">
    <title>Update Equivalence</title>
    <!-- CSS styles -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease forwards;
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
            animation: slideInDown 0.5s ease forwards;
        }

        form {
            text-align: left;
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea,
        select,
        input[type="file"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .dynamic-inputs {
            display: none;
        }

        .fadeIn {
            animation: fadeIn 0.5s ease forwards;
        }

        #linksContainer {
            margin-bottom: 20px;
        }

        #addLink {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 8px 12px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        #addLink:hover {
            background-color: #0056b3;
        }

        .preview-container {
            margin-bottom: 20px;
        }

        .preview-container img,
        .preview-container .file-name {
            display: block;
            margin-bottom: 5px;
        }

        .preview-container .delete-button {
            color: red;
            cursor: pointer;
            display: inline-block;
            margin-left: 10px;
        }

        .preview-container .delete-button:hover {
            text-decoration: underline;
        }

        .file-preview {
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            display: inline-block;
        }

        @media screen and (max-width: 600px) {
            form {
                padding: 0 20px;
            }

            input[type="text"],
            textarea,
            select,
            input[type="file"] {
                width: calc(100% - 20px);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        button[type="submit"],
        button[type="reset"] {
            width: 48%;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        button[type="submit"]:hover,
        button[type="reset"]:hover {
            background-color: #0056b3;
        }

        #addLink {
            width: 48%;
            padding: 20px;
            margin-top: auto;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Courier New', Courier, monospace;
            transition: background-color 0.3s;
            font-size: 16px;
        }

        /* Card Styles */
        .card {
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, color 0.3s;
        }

        .card:hover {
            background-color: #333;
            color: #ffffff;
        }
    </style>
</head>


<body>
    <div class="container">
        <?php
        // Connect to your database here
        $conn = new mysqli($servername, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $article_id = $_GET['id']; // Assuming you're getting the article ID from the URL

        $sql = "SELECT * FROM equivalence WHERE id='$article_id'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='grid'>";
                echo "<div class='card'>";
                echo "<div class='content'>";
                echo "<p><strong>ID:</strong> " . $row["id"] . "</p>";
                echo "<p><strong>Title:</strong> " . $row["title"] . "</p>";
                echo "<p><strong>Description:</strong> " . $row["description"] . "</p>";

                // Fetch and display associated images if any
                $fetch_images_sql = "SELECT * FROM equivalence_images WHERE equivalence_id = ?";
                $fetch_images_stmt = $conn->prepare($fetch_images_sql);
                $fetch_images_stmt->bind_param("i", $article_id);
                $fetch_images_stmt->execute();
                $images_result = $fetch_images_stmt->get_result();
                if ($images_result->num_rows > 0) {
                    echo "<p><strong>Associated Images:</strong></p>";
                    echo "<div class='preview-container'>";
                    while ($image_row = $images_result->fetch_assoc()) {
                        echo "<img src='" . $image_row['image_path'] . "' class='mb-2'>";
                    }
                    echo "</div>";
                }

                echo "<p><strong>Created At:</strong> " . $row["created_at"] . "</p>";
                echo "<div class='contain_two_btn'>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "0 results";
        }
        $conn->close();
        ?>
    </div>

    <div class="container">
        <!-- Form for updating an article -->
        <h2>Update Article</h2>
        <form method="post" enctype="multipart/form-data">
            <!-- Input fields for article details -->
            <!-- Title -->
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required><br>

            <!-- Content -->
            <label for="content">Description:</label>
            <textarea id="content" name="content" rows="4" required></textarea><br>

            <!-- File Upload -->
            <label for="files">Upload Images:</label>
            <input type="file" id="files" name="files[]" multiple><br>

            <!-- Submit button -->
            <button type="submit" name="update" onclick="return confirm('Are you sure you want to update this equivalence?')">Update Article</button>
            <!-- Reset button -->
            <button type="reset">Reset</button>
            <div style="padding: 4px; width:auto; height:25px; background-color:#333; color:#f9f9f9;"><a href="/access/php/admin_page/admin_panal.php?id="<?php echo $admin_id;?>" target="_blank" rel="noopener noreferrer" style="color:#f9f9f9; font-family:Georgia, 'Times New Roman', Times, serif; font-weight:bolder;">Return To Admin Page</a></div>

        </form>
    </div>
    <!-- JavaScript code for previewing images -->
    <script>
        document.getElementById('images').addEventListener('change', function () {
            var files = this.files;
            var filePreview = document.querySelector('.preview-container');
            filePreview.innerHTML = '';
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var img = document.createElement('img');
                img.src = URL.createObjectURL(file);
                img.classList.add('preview-image');
                filePreview.appendChild(img);
            }
        });
    </script>
</body>

</html>
