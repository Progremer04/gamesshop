<?php
// Check if the ID parameter is set and not empty
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Include database connection
    
    // Connect to your database here
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Start a transaction
    $conn->begin_transaction();
    $admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : ''; // Get the admin ID from the URL parameter

    try {
        
        // Prepare a DELETE statement for admin
        $sql_admin = "DELETE FROM admins WHERE id = ?";
        $stmt_admin = $conn->prepare($sql_admin);
        $stmt_admin->bind_param("i", $admin_id);

        // Set parameter for all statements
        $admin_id = $_GET['id'];

        // Execute the statements
        $stmt_admin->execute();

        // Commit the transaction
        $conn->commit();

        // Redirect back to the admin page after successful deletion
        header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);
        exit();
    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $conn->rollback();

        // Display an error message
        echo "Error deleting record: " . $e->getMessage();
    }

    // Close statements

    $stmt_admin->close();

    // Close connection
    $conn->close();
} else {
    // If no ID parameter is provided, redirect to admin page
    header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);
    exit();
}
?>
