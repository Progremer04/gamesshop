<?php
$servername = "localhost";
$username = "id21942922_root";
$password = "Amine@2004";
$dbname = "id21942922_dietyour"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
