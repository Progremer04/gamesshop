<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin ContactPage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        .admin-card {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .admin-card h3 {
            margin-top: 0;
            color: #007bff;
        }
        .admin-card button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
            transition: background-color 0.3s ease;
        }
        .admin-card button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admins</h1>
        <?php
        // Assuming you have already connected to your database

       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

// Connect to the database
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
        $user_id= isset($_GET['id'])?$_GET['id']:null;
        // Fetch all admins from the database
        $sql = "SELECT * FROM admins";
        $result = $conn->query($sql);

        // Check if there are any admins
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<div class='admin-card'>";
                echo "<h3>Admin: " . $row["firstname"] . "   " . $row["lastname"] . "</h3>";
                echo "<a href='/access/php/chatapp/chat.php?sender_id=" . $user_id . "&receiver_id=" . $row["id"] . "&admin_id=" . $row["id"] . "'><button>Chat</button></a>";
                echo "</div>";
            }
        } else {
            echo "No admins found.";
        }
        ?>
    </div>
</body>
</html>
