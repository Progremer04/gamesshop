<?php
// Check if the ID parameter is set and not empty
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Include database connection
    
    // Connect to your database here
        $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Start a transaction
    $conn->begin_transaction();
    $admin_id = isset($_GET['adminid']) ? $_GET['adminid'] : ''; // Get the admin ID from the URL parameter
    
    try {
        // Prepare a DELETE statement for article_files
        $sql_files = "DELETE FROM equivalence_images WHERE equivalence_id = ?";
        $stmt_files = $conn->prepare($sql_files);
        $stmt_files->bind_param("i", $equivalence_id);
        
        // Prepare a DELETE statement for equivalence
        $sql_equivalence = "DELETE FROM equivalence WHERE id = ?";
        $stmt_equivalence = $conn->prepare($sql_equivalence);
        $stmt_equivalence->bind_param("i", $equivalence_id);

        // Set parameter for all statements
        $equivalence_id = $_GET['id'];

        // Execute the statements
        $stmt_files->execute();
        $stmt_equivalence->execute();

        // Commit the transaction
        $conn->commit();

        // Redirect back to the admin page after successful deletion
        header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);
        exit();
    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $conn->rollback();

        // Display an error message
        echo "Error deleting record: " . $e->getMessage();
    }

    // Close statements
    $stmt_files->close();
    $stmt_links->close();
    $stmt_equivalence->close();

    // Close connection
    $conn->close();
} else {
    // If no ID parameter is provided, redirect to admin page
    header("Location: /access/php/admin_page/admin_panal.php?id=" . $admin_id);
    exit();
}
?>
