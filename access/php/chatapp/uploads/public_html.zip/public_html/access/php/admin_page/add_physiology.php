<?php
// Establish a connection to the MySQL database
       $servername = "localhost";
        $username = "id21942922_root";
        $password = "Amine@2004";
        $database = "id21942922_dietyour"; // Replace with your actual database name

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize them
    $title = $conn->real_escape_string($_POST['title']);
    $link = $conn->real_escape_string($_POST['link']);

    // Insert physiology details into the 'physiologies' table
    $sql = "INSERT INTO physiologies (title, link) VALUES ('$title', '$link')";
    if ($conn->query($sql) === TRUE) {
        // Redirect to a specific page after successful insertion
        header('Location: /access/php/admin_page/crate_phsilogie.php');
        exit; // Ensure that no other code is executed after the redirection
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
